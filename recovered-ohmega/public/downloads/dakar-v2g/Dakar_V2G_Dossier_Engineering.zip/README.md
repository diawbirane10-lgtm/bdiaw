# Dakar V2G — simulateur temporel et dossier R2

Ouvrir **Dakar_V2G_Architecture_Revisee.html** dans un navigateur moderne. Aucun serveur, compte ou Node-RED requis. Simulation, plan 3D, textes et import GeoJSON fonctionnent hors ligne. Fond OpenStreetMap et liens de sources nécessitent Internet. Aucun équipement ou système Senelec connecté.

## Utiliser le laboratoire

1. Onglet **Simulateur** : choisir un programme et les paramètres initiaux (SoC, réserve, puissance, solaire, export hypothétique, secours). Les paramètres sont verrouillés quand l'essai commence ; Réinitialiser permet un autre essai.
2. **Lancer / Pause**, **+ 1 min**, ou **Calculer jusqu'à la fin**. La vitesse de lecture modifie la lecture, pas le pas énergétique de 5 secondes ni le résultat.
3. Programmer des événements ou les injecter maintenant : coupure/retour du réseau, perte/retour Internet, départ/retour véhicule, début/fin flexibilité, baisse solaire, limite et essais hostiles. Application au prochain pas. Un événement passé est refusé. Le programme peut être consulté et les événements futurs retirés.
4. Lire les flux **Énergie / Données / Cyber**, les puissances au PCC, les SoC, l'énergie non servie, les journaux et les courbes. Le curseur de relecture affiche le passé sans réécrire le calcul ; Lancer reprend l'état courant s'il reste du temps.
5. Vue **Plan 3D** : choisir site A/B, glisser pour tourner, boutons ou flèches clavier, zoom et vue de dessus. Sélectionner borne, véhicule, local électrique, PCC, PV ou stockage pour lire leur rôle. Le menu accessible fournit les mêmes informations. Déplacer la borne avec les positions X/Y ; cela modifie le plan, pas le modèle énergétique.
6. Mémoriser un essai, réinitialiser et modifier le V2G pour mémoriser le second. Le tableau dit si les conditions correspondent. Export JSON complet (configuration/événements/chroniques/bilan/positions/comparaison) et CSV des chroniques.

## Essai de comparaison reproductible

Choisir « V1G / V2G et réserve », garder les autres paramètres par défaut et cocher « Export autorisé dans cet essai » (hypothèse exclusivement). Désactiver V2G, finir, mémoriser. Réinitialiser, activer V2G, finir, mémoriser. Les événements et la durée sont identiques. Dans ce cas fictif, le V2G réduit l'écart à la consigne mais augmente la recharge ultérieure et les pertes : aucune rentabilité ou baisse d'énergie garantie.

« Coupure et épuisement du secours » active la batterie fixe et choisit 360 minutes. Le réseau tombe à 15 minutes. Seuls ≤1 kW de services critiques/site peuvent être alimentés ; le stockage s'épuise. Sans secours, aucune continuité de puissance n'est inventée.

## Carte et limites

La scène 3D est un **plan local illustratif en mètres**, pas une reconstruction géographique de Dakar et pas une implantation validée. Une borne et un véhicule sont agrégés par site, les places vides représentent des extensions possibles. L'onglet Carte conserve des repères géographiques approximatifs, un fond OSM sur demande et l'import GeoJSON WGS84 de points/lignes/polygones. Aucun inventaire réel des bornes ou réseau électrique détaillé n'est fourni. La chaîne QGIS / Kepler.gl / MapLibre est expliquée dans la revue.

Les données sont fictives. Le moteur est quasi-statique : bilans AC/DC et contraintes, pas de tension/fréquence/transitoires, thermique, vieillissement, câble ou protection réelle. Rendement EV 94 % dans chaque sens ; 60 kWh/site ; 22 kW charge et 6 kW décharge. Secours 12 kWh/site, SoC 70 %, plancher 40 %, rendement 90 %, non rechargé pendant l'essai. Délestage du site supposé si puissance insuffisante ; énergie manquante déclarée. Garde cyber logique seulement, sans TLS/PKI. Aucune donnée temps réel ou API Senelec, aucun essai industriel, aucune publication publique.

## Reconstruire et vérifier

Python 3 et Node.js servent uniquement au développement. Depuis `ingenierie` :

```sh
python3 build.py
node tests/model.cjs
node tests/temporal.cjs
npm install
npx playwright install chromium
npm run test:browser
npm run test:simulation-ui
```

Le build écrit l'HTML au niveau supérieur. Les tests navigateur utilisent par défaut Playwright et son Chromium installé. L'environnement de vérification initial : Node 24.19.0, Playwright 1.62.1, Chromium 153.0.8010.0. Les variables optionnelles PLAYWRIGHT_MODULE et CHROMIUM_PACKAGE permettent un runtime externe ; elles ne sont pas nécessaires à l'utilisateur de la page.

Résultats R2 : 96 séquences, 311 042 contrôles de pas, 11 essais supplémentaires ; 10 tailles d'écran du simulateur et 40 contrôles couche/vue. Régressions : 4 000 cas modèle historique, 90 couples scénario/vue et 36 couples onglet/vue sur neuf tailles. Aucune erreur de page ou requête externe dans les parcours hors ligne testés. Preuves, captures examinées, corrections et risques dans le dossier. Le fond OSM externe, un audit WCAG complet et l'installation physique restent NON TESTÉS.

R1 reste documentée dans les historiques. Les sources ont été consultées le 9 octobre 2026 ; R2 datée du 10 octobre ajoute le logiciel, aucune mesure de terrain. MANIFEST.sha256 contient les empreintes des fichiers distribués. La remise sert à l'étude et à la présentation ; elle ne qualifie pas une installation.
