# Architecture recommandée — Dakar V2G, concept R1

## Décision

Le meilleur point de départ proposé est une flotte captive sur un dépôt ou parking maîtrisé, raccordé au réseau Senelec, avec recharge pilotée, compteur PCC, EMS local, contrôle secouru par UPS et supervision centrale. Le V2G vers le réseau constitue une seconde phase sous conditions de matériel, de raccordement et de convention. PV, stockage fixe et accès télécom secondaire restent des options à justifier par profil, continuité et TCO.

Il serait prématuré de recommander une source autonome principale ou un réseau public réparti entre des quartiers sans mesures d’usage et de capacité électrique. Cette conclusion est une inférence de conception, pas un résultat économique mesuré à Dakar.

## Architecture physique

Par site : réseau public ↔ PCC (isolement, protections et compteur bidirectionnel) ↔ bus AC ↔ convertisseur de borne DC ↔ véhicule compatible. Les charges du bâtiment sont alimentées depuis le même bus. Le PV injecte vers ce bus, sous conditions de conception ; une batterie fixe et son convertisseur bidirectionnel sont facultatifs.

L’UPS auxiliaire maintient seulement les fonctions de contrôle/communication sur une autonomie à dimensionner. Le secours de puissance est un système distinct : isolement sûr, appareil formant le réseau de l’îlot, protection adaptée dans chaque mode, délestage, resynchronisation et essais. Le véhicule ne constitue pas une capacité de secours ferme. Aucune injection publique ne continue en coupure.

## Architecture de contrôle et communication

Protections électriques locales matérielles, puis EMS de site avec limites PCC, réserve au départ et stratégie de repli. Supervision/agrégateur au-dessus pour prévoir, publier les capacités, coordonner et mesurer. L’intégration du fabricant doit garantir une seule autorité finale de consigne ; éviter deux maîtres OCPP concurrents.

Sur site : Ethernet/fibre selon l’implantation et l’équipement. Entre sites distants et supervision : IP sur accès fixe/mobile. Les contraintes de portée locale d’un câble ou d’une radio ne limitent pas la distance de bout en bout sur IP. L’accès secondaire se choisit après QoS et examen des causes communes, pas pour afficher une redondance théorique.

Messages utiles : puissance PCC, état, limites admissibles import/export, réserve et énergie mobilisable, durée de disponibilité, alarmes et validité. Consignes : kW, fenêtre, identifiant, expiration, acquittement et résultat mesuré. Une information agrégée peut être partagée ; les sites ne prennent pas le contrôle direct de leurs voisins.

ISO 15118-20 concerne la relation véhicule–borne selon support. OCPP 2.1 est la cible nouvelle borne–supervision pour les fonctions bidirectionnelles. L’interface réseau/agrégateur doit être convenue avec Senelec ; elle ne découle pas du seul choix d’OCPP. Des matériels existants OCPP plus anciens peuvent rester utiles pour le G2V, sans promesse de mise à jour V2G.

Télémesure 5 s et consigne valable 15 s sont des hypothèses de départ à essayer. Les protections ne passent jamais par une boucle temps réel cloud. Le modèle calcule les énergies par pas de 15 min, une échelle distincte de la validité de commande.

## Cybersécurité

Séparation OT/IT, identités par équipement, mTLS/PKI, moindre privilège, MFA administration, aucune borne directement exposée en entrée sur Internet. Expiration et anti-rejeu, contrôle des valeurs et mesures fraîches, arbitre local, journaux horodatés, révocation et détection d’incident. Mises à jour signées, restauration et retour arrière testés, maintenance à accès borné.

La fonction JavaScript ne fait qu’illustrer les décisions de refus ; les booléens d’identité sont des données de fixture. Aucun chiffrement, certificat ni protocole électrique industriel n’est implémenté. Une commande authentifiée peut rester dangereuse ; les protections matérielles sont indépendantes. Collecte minimale des sessions et de la disponibilité, sans profil de déplacement inutile.

## Cartographie et données

QGIS est recommandé pour la présélection multicouche ; OSM/Geofabrik et Overture fournissent des données géographiques, Kepler.gl sert à l’exploration et MapLibre à une future interface web. Aucun de ces outils ne possède par défaut la capacité de raccordement Senelec. Les données urbaines peuvent être incomplètes, datées ou sous licences différentes.

La page inclut un cadre de coordonnées et des repères de villes approximatifs, un fond OSM externe activable et un import GeoJSON local. Il n’y a ni tracé de réseau électrique validé, ni emplacement de borne décidé. Le fond externe nécessite Internet et n’a pas été testé en disponibilité. L’application métier future devrait croiser des couches datées et maîtrisées, avec accès restreint aux détails électriques sensibles.

Publications Senelec : rapports, chiffres clés et procédure de raccordement vérifiés. CRSE : rapport 2024, décisions tarifaires 2026 et modification 2025 du cadre d’autoproduction repérés, sans assimilation juridique du V2G ni rémunération supposée. ARTP : SUNU Carto et campagnes QoS repérés, pages en erreur 502 lors de récupération ; aucune API ou couche brute obtenue. Les statistiques nationales n’identifient pas un départ local. L’inventaire donne les étapes d’acquisition manquantes.

## Originalité et pertinence

Le contrôle local hors cloud, le multisite et l’agrégation V2G sont déjà proposés industriellement. Les annonces CFAO/BYD en 2024 montrent un écosystème en développement au Sénégal ; elles ne prouvent pas le nombre actuel de bornes ou la disponibilité de V2G.

La contribution possible est une enveloppe de flexibilité fiable avec contraintes électriques locales, disponibilité/heure de départ/réserve des véhicules et confiance/fraîcheur des mesures. Pour la démontrer, comparer recharge non pilotée, V1G et V2G ; retirer les télémesures dégradées ; tester une commande excessive même authentifiée. Une revue bibliographique ciblée reste nécessaire avant toute revendication de nouveauté scientifique mondiale.

## Boucle de revue

1. Recherche et confrontation des hypothèses sous treize angles métier ; corrections de concept.
2. Construction du modèle, vérification des invariants et renforcement des refus.
3. Vérification dans Chromium réel, inspection des captures, corrections UI/SVG et reprises PASS.

Cette boucle augmente la cohérence du concept ; elle ne résout pas les inconnues terrain par une simulation. Les mêmes rôles sont joués successivement par l’assistant. Aucun audit professionnel indépendant n’est revendiqué.

## Objections détaillées et corrections

### RVW-001 — Systèmes

Hypothèse : « Bornes intelligentes + V2G » suffirait à constituer une innovation.

Faille : Pilotage de charge, contrôleur local et agrégation existent déjà chez The Mobility House et Nuvve.

Correction : Réutiliser les standards ; évaluer une flexibilité fiable sous contraintes locales et communications dégradées.

Preuve future : Comparaison V1G / V2G / commande centralisée, sur traces terrain.

### RVW-002 — Électricité

Hypothèse : Injection à Keur Massar pour compenser une surcharge au centre.

Faille : Deux sites peuvent dépendre de départs différents ; un bilan agrégé masque les contraintes locales.

Correction : Plafonds import/export propres à chaque PCC et identification du départ électrique.

Preuve future : Étude de flux, tension, protections, harmoniques et capacité de raccordement Senelec.

### RVW-003 — Conversion

Hypothèse : Une borne, une prise ou un véhicule électrique est forcément bidirectionnel.

Faille : V2L, V2B et V2G diffèrent. La fonction dépend du couple véhicule–borne, du logiciel et des garanties.

Correction : Essayer un couple compatible avant achat ; ISO 15118-20 comme cible lorsque pris en charge.

Preuve future : Essais de charge/décharge, constructeur, garantie batterie et interopérabilité.

### RVW-004 — Résilience

Hypothèse : Le V2G assurerait la recharge pendant toute coupure.

Faille : Les véhicules partent ; un équipement suiveur de réseau ne crée pas un réseau autonome.

Correction : En coupure : isolement du PCC, arrêt des échanges réseau. V2B/îlotage comme variante distincte.

Preuve future : Essais de transfert, formation de réseau, sélectivité et resynchronisation.

### RVW-005 — Économie

Hypothèse : Installer PV et grosses batteries partout, en doublant tout.

Faille : CAPEX, pertes, maintenance et vieillissement peuvent annuler le bénéfice ; la disponibilité réelle n’est pas mesurée.

Correction : Réseau principal ; UPS du contrôle ; PV et stockage seulement si un cas d’usage chiffré les justifie.

Preuve future : TCO : raccordement, borne, énergie, abonnement, dégradation, télécom et indisponibilité. Aucun revenu V2G présumé.

### RVW-006 — Télécom

Hypothèse : Les bornes auraient besoin d’une radio directe couvrant toute l’agglomération.

Faille : La portée radio n’est pas la portée d’un réseau IP. Le maillage intégral ajoute des dépendances.

Correction : Ethernet/fibre sur site ; accès IP fixe ou mobile vers supervision. Aucun pair distant ne commande directement une borne.

Preuve future : Mesures QoS sur site, délais p95/p99, perte de paquets, coupures et reprise.

### RVW-007 — Contrôle

Hypothèse : Toute la boucle devrait être « temps réel » dans le cloud.

Faille : La latence réseau variable ne convient pas aux protections électriques.

Correction : Protections locales matérielles ; EMS local ; coordination centrale moins rapide, assortie d’une durée de validité.

Preuve future : Cibles de départ : télémesure 5 s, validité 15 s ; hypothèses à ajuster. Pas de temps réel dur à l’échelle de la ville.

### RVW-008 — Cybersécurité

Hypothèse : TLS protégerait à lui seul contre toute mauvaise consigne.

Faille : Une identité autorisée peut être compromise ; rejeu, maintenance distante et mises à jour restent des chemins d’attaque.

Correction : Identités par équipement, mTLS, rôles, segmentation OT/IT, expiration, limites locales et audit.

Preuve future : Test d’intrusion, certificats révoqués, messages périmés, commande excessive et reprise sans consigne ancienne.

### RVW-009 — Données

Hypothèse : La supervision aurait besoin de tous les déplacements et de l’identité personnelle.

Faille : Collecte inutile, risques de confidentialité et données parfois indisponibles selon le véhicule.

Correction : Pseudonyme de session, disponibilité, énergie demandée et heure de départ ; SoC seulement si accessible et consenti.

Preuve future : Politique de conservation, contrôle d’accès, consentement et validation du cadre de protection des données.

### RVW-010 — Régulation

Hypothèse : Le raccordement autoriserait automatiquement l’injection rémunérée.

Faille : Autorisation, comptage, responsabilité, contrat et paiement V2G ne sont pas établis par cette recherche.

Correction : Phase 1 : recharge pilotée. Phase 2 : V2G après position écrite Senelec/CRSE et essais.

Preuve future : Qualification juridique du service, convention de raccordement, limite d’export et méthode de mesure.

### RVW-011 — SIG

Hypothèse : Un bâtiment proche d’une ligne visible sur une carte serait raccordable.

Faille : OSM/Overture décrivent la géographie ; les réseaux cartographiés peuvent être incomplets et sans paramètres électriques.

Correction : Filtrer les accès et usages en SIG, puis valider chaque candidat avec Senelec et mesures terrain.

Preuve future : Provenance, date, licence, précision, relevé du site et dossier de raccordement.

### RVW-012 — Exploitation

Hypothèse : Déployer d’abord un réseau public dans des quartiers arbitraires.

Faille : Demande, immobilisation des véhicules, propriété, sécurité et entretien restent inconnus.

Correction : Premier pilote sur une flotte captive, dans un dépôt ou parking contrôlé ; second site d’abord simulé.

Preuve future : Inventaire de flotte, journal des arrivées/départs, besoin de recharge, accès maintenance.

### RVW-013 — Environnement

Hypothèse : Reprendre un dimensionnement européen tel quel.

Faille : Chaleur, poussière, air salin, pluie, inondation, vandalisme et accessibilité peuvent modifier le choix.

Correction : Inspection locale ; indices de protection et déclassement thermique définis selon le site et le fournisseur.

Preuve future : Relevé hydrologique/terrain, ventilation, corrosion, drainage, génie civil, sécurité incendie et accès secours.

## Réception et prochaines preuves

Le démonstrateur est vérifié dans son périmètre : 4 000 combinaisons de modèle, cas de commandes hostiles, neuf tailles d’écran, scénarios, clavier, import et export. Le rapport distingue les corrections et les tests. Toute installation demeure conditionnée au profil de flotte, à l’étude Senelec, au couple compatible, aux garanties, au cadre contractuel, aux protections et à une validation indépendante sur équipement.

Le pilote doit mesurer : énergie livrée et besoin au départ, pointe locale, flexibilité annoncée/réalisée, taux de service non satisfait, disponibilité WAN/local, reprises, cycles/énergie de décharge et TCO. Les seuils d’acceptation opérationnels seront négociés d’après le besoin, pas inventés dans cette démonstration.

Format de présentation : un fichier HTML autonome ; aucun serveur Node-RED nécessaire. Un déploiement statique HTTPS est possible ensuite, mais n’a pas été effectué.


## Extension R2 — 10 octobre 2026

Le livrable R2 ajoute un moteur temporel déterministe à pas 5 s et une scène 3D manipulable. Paramètres avant essai ; événements pendant essai ; lecture accélérée, pause, pas minute, reset, fin directe ; courbes PCC/SoC, journaux et métriques d'énergie ; historique sans modifier le passé ; comparaison de deux essais et exports JSON/CSV. Les changements de position 3D sont graphiques et ne simulent pas le câblage.

Décision maintenue : réseau principal, EMS local borné, coordination centralisée sans maillage direct inutile, V1G de base et V2G conditionnel. L'architecture à réaliser reste soumise à la puissance de raccordement, au couple compatible, au consentement/garantie et au cadre d'injection. Le secours de puissance n'est pas doublé partout automatiquement ; le laboratoire permet de tester sa valeur et son épuisement.

Vérification : TST-S01/S02 et régression R1 PASS. La comparaison par défaut avec export supposé autorisé montre 9,7 kWh AC de décharge V2G et un écart à la consigne supprimé, mais 11 kWh AC de recharge supplémentaires ; aucune rentabilité déduite.

Plan 3D illustratif par site, pas une ville 3D géographique. Cartographie régionale et GeoJSON disponibles ; QGIS/Kepler/MapLibre restent la chaîne d'étude décrite en R1, aucune bibliothèque externe ajoutée au fichier hors ligne. Données Senelec/ARTP/CRSE de terrain et flux industriels toujours non intégrés. Verdict : PASS pour le simulateur, pas de libération industrielle.
