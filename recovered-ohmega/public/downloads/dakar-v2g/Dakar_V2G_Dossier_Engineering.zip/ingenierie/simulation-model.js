/* Simulation énergétique déterministe ; pas électrique de 5 s, aucune connexion matérielle. */
'use strict';
const TemporalModel=(()=>{
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 const defaults={duration:240,startHour:10,profile:true,pv:true,v2g:true,exportAllowed:false,backup:false,reserve:60,target:-2,socA:55,socB:70,targetSoc:85,departureA:180,departureB:240,loadA:12,loadB:8,pvA:8,pvB:6,importA:40,importB:40};
 const labels={flexOn:'Début de flexibilité',flexOff:'Fin de flexibilité',gridOff:'Coupure du réseau',gridOn:'Retour du réseau',wanOff:'Perte Internet',wanOn:'Retour Internet',depart:'Départ du véhicule',arrive:'Retour du véhicule',cloud:'Baisse du solaire',sun:'Retour du solaire',limit:'Réduction du plafond A',unlimit:'Retour du plafond A',identity:'Identité inconnue',replay:'Rejeu de commande',unsafe:'Commande de 100 kW',reserve:'Réserve figée au SoC courant'};
 const presets={
  mixed:[{at:30,type:'flexOn'},{at:60,type:'unsafe'},{at:70,type:'identity'},{at:80,type:'replay'},{at:90,type:'flexOff'},{at:110,type:'gridOff'},{at:130,type:'gridOn'},{at:145,type:'wanOff',site:'B'},{at:165,type:'wanOn',site:'B'},{at:175,type:'cloud'},{at:195,type:'sun'},{at:210,type:'depart',site:'B'}],
  support:[{at:20,type:'flexOn'},{at:100,type:'flexOff'}],
  backup:[{at:15,type:'gridOff'}],
  departure:[{at:0,type:'flexOn'},{at:30,type:'depart',site:'B'},{at:100,type:'flexOff'}],
  empty:[]
 };
 function config(c={}){
  const r={...defaults,...c};
  for(const k of ['profile','pv','v2g','exportAllowed','backup'])r[k]=r[k]===true;
  const bounds={duration:[30,720],startHour:[0,23],reserve:[0,95],target:[-30,100],socA:[0,100],socB:[0,100],targetSoc:[0,100],departureA:[1,720],departureB:[1,720],loadA:[0,50],loadB:[0,50],pvA:[0,50],pvB:[0,50],importA:[1,80],importB:[1,80]};
  for(const [k,[lo,hi]]of Object.entries(bounds)){if(!Number.isFinite(r[k]))throw Error('Paramètre numérique invalide : '+k);r[k]=clamp(r[k],lo,hi);}
  r.duration=Math.round(r.duration);r.departureA=Math.round(r.departureA);r.departureB=Math.round(r.departureB);r.targetSoc=Math.max(r.targetSoc,r.reserve);return r;
 }
 class Engine{
  constructor(c={},events=[]){
   this.config=config(c);this.time=0;this.dt=5;this.grid=true;this.flex=false;this.solarFactor=1;this.sequence=0;this.seen=new Set();this.logs=[];this.history=[];this.lastReject=null;
   this.events=events.map((e,i)=>this.event(e,'p'+i)).sort((a,b)=>a.at-b.at||a.order-b.order);
   this.sites=['A','B'].map(id=>({id,capacity:60,energy:60*this.config['soc'+id]/100,initialEnergy:60*this.config['soc'+id]/100,bessEnergy:12*.70,bessInitial:12*.70,present:true,wan:true,lastTelemetry:0,lastKnownPower:0,limit:this.config['import'+id],reserveOverride:null,departure:this.config['departure'+id]*60,departures:0,unservedDeparture:0}));
   this.metrics={importKWh:0,exportKWh:0,chargeKWh:0,dischargeKWh:0,pvKWh:0,curtailedKWh:0,unservedKWh:0,criticalUnservedKWh:0,bessKWh:0,conversionLossKWh:0,unmetKWh:0,peakImport:0,rejected:0,dcThroughput:0,servedLoadKWh:0,requestedLoadKWh:0};
   this.frame=this.calculate(false);this.frame.time=0;this.history.push(this.snapshot());
  }
  event(e,id){
   if(!e||!Number.isFinite(e.at)||e.at<0||e.at>720||!Object.hasOwn(labels,e.type)||!['A','B','all',undefined].includes(e.site))throw Error('Événement invalide.');
   return {at:e.at,type:e.type,site:e.site||'all',id,order:this.sequence++,done:false};
  }
  schedule(e){const r=this.event(e,'m'+this.sequence);if(r.at*60<this.time)throw Error('Événement placé dans le passé.');this.events.push(r);this.events.sort((a,b)=>a.at-b.at||a.order-b.order);return r;}
  log(type,message){this.logs.push({time:this.time,type,message});}
  leave(s,reason){
   if(!s.present)return;s.present=false;s.departures++;const deficit=Math.max(0,this.config.targetSoc/100*s.capacity-s.energy);s.unservedDeparture+=deficit;
   this.log('depart',`Site ${s.id} : ${reason}, SoC ${(s.energy/s.capacity*100).toFixed(1)} %, manque au départ ${deficit.toFixed(2)} kWh DC.`);
  }
  apply(e){
   const all=this.sites.filter(s=>e.site==='all'||s.id===e.site);e.done=true;
   switch(e.type){
    case 'flexOn':this.flex=true;break;case 'flexOff':this.flex=false;break;
    case 'gridOff':this.grid=false;break;case 'gridOn':this.grid=true;break;
    case 'cloud':this.solarFactor=.2;break;case 'sun':this.solarFactor=1;break;
    case 'wanOff':for(const s of all)s.wan=false;break;case 'wanOn':for(const s of all)s.wan=true;break;
    case 'depart':for(const s of all)this.leave(s,'départ injecté');break;
    case 'arrive':for(const s of all){s.present=true;s.departure=Math.max(s.departure,this.time+3600);}break;
    case 'limit':this.sites[0].limit=Math.min(20,this.config.importA);break;
    case 'unlimit':this.sites[0].limit=this.config.importA;break;
    case 'reserve':for(const s of all)s.reserveOverride=s.energy/s.capacity*100;break;
    case 'identity':case 'replay':case 'unsafe':{
     const s=all[0]||this.sites[0];const bounds=this.bounds(s);const context={now:this.time,seen:this.seen,telemetryFresh:s.wan,gridPresent:this.grid,lo:bounds.lo,hi:bounds.hi};
     const c={id:e.id,authenticated:e.type!=='identity',authorized:true,expires:this.time+10,power:e.type==='unsafe'?100:0};
     if(e.type==='replay'){this.seen.add(c.id);}
     const check=EnergyModel.validateCommand(c,context);if(!check.ok){this.metrics.rejected++;this.lastReject={time:this.time,check};}
     this.log('reject',`${labels[e.type]} au site ${s.id} : ${check.ok?'acceptée (fixture)':`REFUS / ${check.reason}`}. Aucun changement de consigne par cet essai hostile.`);return;
    }
   }
   this.log(e.type,labels[e.type]+(['wanOff','wanOn','depart','arrive','reserve'].includes(e.type)?' · site '+e.site: '')+'.');
  }
  demand(s){
   const t=this.time/60,h=(this.config.startHour+t/60)%24;
   const f=this.config.profile ? .9+.1*Math.sin(2*Math.PI*t/180+(s.id==='A'?0:1)) : 1;
   const load=this.config['load'+s.id]*f;
   const sun=this.config.profile?Math.max(0,Math.sin(Math.PI*(h-6)/12)):1;
   const pv=this.config.pv?this.config['pv'+s.id]*sun*this.solarFactor:0;
   return {load,pv};
  }
  bounds(s){
   const c=this.config,dt=this.dt/3600,d=this.demand(s);
   const requestedLoad=d.load,servedLoad=Math.min(requestedLoad,s.limit+d.pv);
   const remaining=Math.max(0,(s.departure-this.time-this.dt)/3600);
   const target=c.targetSoc/100*s.capacity,reserve=Math.max(c.reserve,s.reserveOverride||0)/100*s.capacity;
   const futureFloor=Math.max(reserve,target-22*.94*remaining);
   const chargeEnergy=Math.max(0,target-s.energy)/(.94*dt);
   const charge=s.present?Math.min(22,chargeEnergy,Math.max(0,s.limit-servedLoad+d.pv)):0;
   const exportLimit=c.exportAllowed?15:0;
   const usedPv=Math.min(d.pv,servedLoad+charge+exportLimit),base=servedLoad-usedPv;
   // Une recharge minimale ne s'impose qu'en dessous du plancher. Au-dessus,
   // ce terme ne doit pas interdire une décharge pourtant autorisée par la réserve.
   const mandatory=s.present&&s.energy<futureFloor?(futureFloor-s.energy)/(.94*dt):-Infinity;
   const discharge=c.v2g&&s.present?Math.min(6,Math.max(0,s.energy-futureFloor)*.94/dt):0;
   const hi=charge,lo=s.present?Math.min(hi,Math.max(-discharge,mandatory,-exportLimit-base)):0;
   return {requestedLoad,servedLoad,pv:d.pv,usedPv,base,lo,hi,reserve:reserve/s.capacity*100,futureFloor:futureFloor/s.capacity*100,exportLimit};
  }
  calculate(integrate){
   const c=this.config,dt=this.dt/3600;
   const sites=this.sites.map(s=>{const b=this.bounds(s);return {...b,id:s.id,capacity:s.capacity,soc:s.energy/s.capacity*100,socAfter:s.energy/s.capacity*100,available:s.present,wan:s.wan,importLimit:s.limit,ev:this.grid?b.hi:0,grid:0,bess:0,bessSoc:s.bessEnergy/12*100,telemetryAge:Math.max(0,this.time-s.lastTelemetry),targetSoc:c.targetSoc};});
   if(this.grid&&this.flex){
    // Sans liaison, ne pas utiliser la vraie puissance cachée : contribution conservatrice à la limite d'import.
    let excess=sites.reduce((n,s)=>n+(s.wan?s.base+s.ev:s.importLimit),0)-c.target;
    for(const s of sites.filter(s=>s.wan)){const reduction=Math.min(Math.max(0,excess),Math.max(0,s.ev-Math.max(0,s.lo)));s.ev-=reduction;excess-=reduction;}
    for(const s of [...sites].reverse().filter(s=>s.wan)){const reduction=Math.min(Math.max(0,excess),Math.max(0,s.ev-s.lo));s.ev-=reduction;excess-=reduction;}
   }
   const rejected=this.lastReject&&this.time-this.lastReject.time<60;
   for(let i=0;i<sites.length;i++){
    const p=sites[i],s=this.sites[i];
    if(!this.grid){p.ev=0;p.usedPv=0;p.bess=c.backup?Math.min(1,p.requestedLoad,Math.max(0,s.bessEnergy-12*.40)*.9/dt):0;p.servedLoad=p.bess;p.grid=0;}
    else{p.usedPv=Math.min(p.pv,Math.max(0,p.servedLoad+p.ev+p.exportLimit));p.grid=p.servedLoad+p.ev-p.usedPv;}
    p.unserved=Math.max(0,p.requestedLoad-p.servedLoad);p.criticalUnserved=Math.max(0,Math.min(1,p.requestedLoad)-p.servedLoad);
    p.mode=p.ev<-.00001?'Décharge':p.ev>.00001?'Recharge':s.present?'Pause':'Absent';
    if(integrate){
     const dc=p.ev>=0?p.ev*.94:p.ev/.94;s.energy+=dc*dt;s.bessEnergy-=p.bess/.9*dt;
     // Tolérance flottante uniquement : aucune énergie inventée pour corriger une contrainte violée.
     if(s.energy<-1e-7||s.energy>s.capacity+1e-7||s.bessEnergy<12*.4-1e-7)throw Error('Invariant de stockage violé.');
     s.energy=clamp(s.energy,0,s.capacity);s.bessEnergy=Math.max(12*.4,s.bessEnergy);
     p.socAfter=s.energy/s.capacity*100;p.bessSoc=s.bessEnergy/12*100;
     const m=this.metrics;m.importKWh+=Math.max(0,p.grid)*dt;m.exportKWh+=Math.max(0,-p.grid)*dt;m.chargeKWh+=Math.max(0,p.ev)*dt;m.dischargeKWh+=Math.max(0,-p.ev)*dt;m.pvKWh+=p.usedPv*dt;m.curtailedKWh+=Math.max(0,p.pv-p.usedPv)*dt;m.unservedKWh+=p.unserved*dt;m.criticalUnservedKWh+=p.criticalUnserved*dt;m.bessKWh+=p.bess*dt;m.conversionLossKWh+=(p.ev>=0?p.ev-dc:dc*-1+p.ev)*dt+p.bess*(1/.9-1)*dt;m.dcThroughput+=Math.abs(dc)*dt;m.servedLoadKWh+=p.servedLoad*dt;m.requestedLoadKWh+=p.requestedLoad*dt;
    }
    if(s.wan){s.lastTelemetry=this.time;s.lastKnownPower=p.grid;p.telemetryAge=0;}
    p.lastKnownPower=s.lastKnownPower;p.departureDeficit=s.unservedDeparture;
   }
   const total=sites.reduce((n,s)=>n+s.grid,0),target=this.flex&&this.grid?c.target:null;
   const unmet=target===null?0:Math.max(0,total-target);
   if(integrate){this.metrics.unmetKWh+=unmet*dt;this.metrics.peakImport=Math.max(this.metrics.peakImport,total);}
   const scene=!this.grid?'outage':sites.some(s=>!s.wan)?'offline':this.flex?'support':!sites[1].available?'absent':'normal';
   return {time:this.time,options:{...c,scenario:scene},sites,total,baseline:sites.reduce((n,s)=>n+s.base+(s.available?18:0),0),target,unmet,island:!this.grid,blocked:!!rejected,commandCheck:rejected?this.lastReject.check:null,events:this.logs.slice(-1).map(l=>l.message),eligibleTelemetry:sites.filter(s=>s.wan).map(s=>s.id),metrics:{...this.metrics}};
  }
  step(){
   if(this.done)return this.frame;
   let event=false;
   for(const e of this.events)if(!e.done&&e.at*60<=this.time){this.apply(e);event=true;}
   for(const s of this.sites)if(s.present&&s.departure<=this.time){this.leave(s,'heure de départ planifiée');event=true;}
   this.frame=this.calculate(true);this.time+=this.dt;this.frame.time=this.time;
   if(this.time%60===0||event||this.done)this.history.push(this.snapshot());
   if(this.done){
    for(const e of this.events)if(!e.done&&e.at*60<=this.time)this.apply(e);
    for(const s of this.sites)if(s.present&&s.departure<=this.time)this.leave(s,'heure de départ planifiée');
    this.frame=this.calculate(false);this.history[this.history.length-1]=this.snapshot();
   }
   return this.frame;
  }
  advance(seconds=60){const end=Math.min(this.config.duration*60,this.time+seconds);while(this.time<end)this.step();return this.frame;}
  finish(){while(!this.done)this.step();return this.frame;}
  get done(){return this.time>=this.config.duration*60;}
  snapshot(){return JSON.parse(JSON.stringify(this.frame));}
  report(){return {version:'R2',scope:'simulation-pedagogique-quasi-statique',config:{...this.config},timeSeconds:this.time,stepSeconds:this.dt,events:this.events.map(({done,order,...e})=>({...e,applied:done})),metrics:{...this.metrics,departureDeficitKWh:this.sites.reduce((n,s)=>n+s.unservedDeparture,0),departures:this.sites.reduce((n,s)=>n+s.departures,0),equivalentCycles:this.metrics.dcThroughput/(2*120)},sites:this.sites.map(s=>({id:s.id,energyKWh:s.energy,soc:s.energy/s.capacity*100,bessEnergyKWh:s.bessEnergy,departureDeficitKWh:s.unservedDeparture})),history:this.history,logs:this.logs};}
 }
 return {Engine,defaults,labels,presets,config};
})();
if(typeof module!=='undefined')module.exports=TemporalModel;
