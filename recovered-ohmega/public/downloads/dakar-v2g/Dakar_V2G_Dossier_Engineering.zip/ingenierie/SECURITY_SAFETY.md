# Limite entre démonstrateur et sûreté industrielle

La page n’accède à aucune borne, aucun réseau Senelec, aucun certificat réel. Les données de simulation sont fictives. Le GeoJSON est lu localement, validé et dessiné sans interpréter ses propriétés comme HTML. Les fichiers sont limités en taille, objets et coordonnées. Le service OSM externe se charge seulement après action de l’utilisateur.

En installation : protections/isolement matériels indépendants du logiciel ; limites import/export par site ; réserve batterie et consentement ; défaut = repli défini. PKI, segmentation, mises à jour signées et audits d’intrusion restent NON TESTÉS.

Les limites du démonstrateur ne sont pas un engagement de sûreté : elles n’assurent ni tension, ni fréquence, ni anti-îlotage, ni conformité, ni sécurité du raccordement réel.


## Extension R2 — 10 octobre 2026

Le nouveau moteur reçoit uniquement des événements synthétiques dans le navigateur. Aucun port, service, secret, token industriel ou équipement. Les booléens d'identité et les fixtures anti-rejeu testent la politique, pas la cryptographie. Le refus d'attaque n'est pas une preuve de résistance à une attaque réelle. Les objets 3D n'ont aucune commande physique.
