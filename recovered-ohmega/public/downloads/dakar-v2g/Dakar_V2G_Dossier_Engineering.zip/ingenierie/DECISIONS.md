# Décisions d’architecture R1 — 9 octobre 2026

| ID | Décision | Justification | Condition de révision |
| --- | --- | --- | --- |
| DEC-001 | Réseau Senelec comme source principale proposée | Moins de surdimensionnement que l’autonomie totale ; priorité à l’usage de recharge | Profil/coût/raccordement démontre un meilleur cas autonome |
| DEC-002 | Flotte captive sur site maîtrisé comme premier pilote | Disponibilité, horaires et autorisations plus observables | Données de demande démontrent la viabilité d’un pilote public |
| DEC-003 | V1G avant V2G réseau | Écrêtage de recharge plus simple ; injection et compatibilité restent inconnues | Couple essayé, convention et service concret validés |
| DEC-004 | Autorité locale et coordination centrale | Respecter les limites PCC malgré panne WAN | Vérification d’intégration fabricant et stratégie hors ligne |
| DEC-005 | Pas de radio longue portée directe ou de tous-à-tous | IP multi-opérateurs/fibre déjà adapté ; éviter complexité et propagation d’une compromission | Cas local exige un protocole direct étudié |
| DEC-006 | UPS contrôle ; PV/BESS/secours WAN conditionnels | Doubler uniquement une fonction dont le besoin est démontré | Continuité, TCO et causes communes mesurés |
| DEC-007 | OCPP 2.1 et ISO 15118-20 comme cibles pour nouvelle voie bidirectionnelle | Fonctions et séparation des interfaces ; support matériel non automatique | Matériel, région, essais et garantie donnent un autre couple compatible |
| DEC-008 | QGIS pour étude, OSM/Overture pour géographie, MapLibre pour future app | Choix proportionné à chaque fonction | Volume réel, licences et couches justifient d’autres outils |
| DEC-009 | HTML/CSS/JS autonome pour la présentation | Téléchargement, partage, ouverture sans installation, modèle inspectable | Besoin backend réel ou maintenance d’une application industrielle |

La communication avec Senelec reste INT-004 à convenir. Ne pas empiler MQTT, OpenADR, IEC 61850 et OCPP sans besoin/interface vérifiée. MQTT peut servir à la télémesure interne, pas de preuve de compatibilité utility. Node-RED peut aider à un banc d’intégration ultérieur ; il n’est ni requis pour présenter le concept ni le support des protections électriques.


## Extension R2 — 10 octobre 2026

DEC-S01 : conserver un HTML natif autonome plutôt qu'un serveur Node-RED pour la présentation téléchargeable. Le simulateur n'est pas le contrôleur industriel.

DEC-S02 : intégration à pas fixe 5 s, capacité EV 60 kWh/site, 94 % par sens. Charge ≤22 kW, décharge ≤6 ; recharge nécessaire pour le départ prioritaire. Le plancher tient compte du temps restant et d'une puissance maximale théorique, pas d'une prévision validée.

DEC-S03 : manque de puissance déclaré comme énergie non servie ; jamais correction de SoC par énergie gratuite. Retour du véhicule conserve son énergie. Secours fini, non rechargé dans l'essai.

DEC-S04 : WAN perdu → supervision collective exclut le site et estime prudemment sa contribution à la limite d'import ; EMS local continue la recharge. Les valeurs physiques du laboratoire restent visibles mais marquées distinctes de la dernière télémesure.

DEC-S05 : scène 3D en projection SVG de volumes métriques, hors ligne ; rotations/zoom et position par site. Géographie dans l'onglet Carte, OSM sur demande et couches GeoJSON locales. Aucune ville 3D téléchargée. Futur géoréférencement dépend des couches et relevés, pas du rendu.

DEC-S06 : conserver la revue R1, les sources datées et le modèle historique comme références ; nouveaux modules distincts et tests de régression. Historique des deux fichiers préservé.
