# Anomalies et inconnues — historique conservé

| ID | Gravité dans ce périmètre | Observation | Traitement et preuve | Statut |
| --- | --- | --- | --- | --- |
| ISS-001 | Mineure | Test attend un moins typographique différent d’Intl | Attente corrigée ; TST-002 final PASS | CLOS |
| ISS-002 | Mineure | Libellé batterie déborde, fils PCC/bus tronqués dans SVG | Libellé raccourci et continuité SVG corrigée ; EV-004A/B inspectées | CLOS |
| ISS-003 | Mineure | Capture fullPage affiche un lien d’évitement hors écran ; animation réduite laisse des pointillés | Transform du lien, retour en haut pour captures, CSS mouvement réduit ; EV-004A/B | CLOS |
| ISS-004 | Bloquante pour terrain | Capacité de raccordement et export inconnus | Étude Senelec + cadre CRSE à obtenir ; aucune dérogation | OUVERT |
| ISS-005 | Bloquante pour terrain | Couple véhicule–borne non essayé | Essai fournisseur et garantie requis ; aucune promesse de compatibilité | OUVERT |
| ISS-006 | Observation | Pages ARTP en erreur de récupération, données brutes non extraites | Repérage par index public signalé, mesurer ensuite sur site | OUVERT |
| ISS-007 | Bloquante pour secours réel | Aucun essai de formation d’îlot et de protections | Variante distincte à concevoir puis examiner indépendamment | OUVERT |

Les anomalies majeures physiques restent ouvertes. Les clôtures mineures concernent seulement le démonstrateur et ses tests. Pas de certification exclusive du producteur ni de validation professionnelle indépendante.


## Extension R2 — 10 octobre 2026

| ID | Exigence | Gravité / fait | Correction et clôture | Propriétaire / statut |
| --- | --- | --- | --- | --- |
| ISS-S01 | AC-S07 | Majeure logiciel : décharge V2G annulée par une contrainte zéro | Contrainte signée applicable seulement sous plancher ; nouveau test V1G/V2G et contrôles indépendants TST-S01/S02 PASS | Production / CLOS pour le simulateur 2026-10-10 |
| ISS-S02 | AC-S02 | Mineure : tick lecture de 72 s pouvait arrondir à 75 s | Accumulation du reste, avances multiples de 5 s ; comparaison de rapport UI finish/120 min/s PASS | Logiciel / CLOS |
| ISS-S03 | AC-S06 | Mineure affichage : SoC secours affiché si non installé | Texte explicite et séries conditionnelles ; UI et captures vérifiées | UI / CLOS |
| ISS-S04 | AC-S06 | Observation du test : fieldset.isDisabled ne qualifie pas les champs | Assertion sur simDuration ; pause et reprise TST-S02 PASS | Évaluation / CLOS |
| ISS-S05 | AC-S08 | Limite déclarée : plan 3D non géoréférencé | Étiquette et export geographicValidation=false ; pas de coordonnées de terrain inventées | Porteur / OUVERT pour étude SIG |

Les blocages terrain R1 ne sont pas levés. Une clôture logiciel n'autorise pas une mise en service.
