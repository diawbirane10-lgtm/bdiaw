const assert=require('node:assert/strict');
const M=require('../model.js');
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
let cases=0;
for(const scenario of Object.keys(M.scenarios))for(const pv of [false,true])for(const v2g of [false,true])for(const exportAllowed of [false,true])for(const backup of [false,true])for(const reserve of [50,60,70,80,90])for(const target of [-4,-2,0,10,40]){
 const r=M.run({scenario,pv,v2g,exportAllowed,backup,reserve,target});cases++;
 near(r.total,r.sites.reduce((n,s)=>n+s.grid,0));
 for(const s of r.sites){
  // Conservation au bus AC : réseau + PV + batterie fixe = bâtiment + borne.
  near(s.grid+s.usedPv+s.bess,s.servedLoad+s.ev);
  assert.ok(s.grid<=s.importLimit+1e-8);
  assert.ok(s.grid>= (exportAllowed?-15:0)-1e-8);
  assert.ok(s.ev<=22+1e-8&&s.ev>=-6-1e-8);
  if(s.ev<0){assert.ok(v2g&&s.available);assert.ok(s.socAfter>=s.reserve-1e-8);}
  if(!s.available)near(s.ev,0);
  if(r.island){near(s.grid,0);near(s.ev,0);near(s.usedPv,0);near(s.servedLoad,backup?1:0);}
  if(s.ev<0)near((s.soc-s.socAfter)*s.capacity/100,-s.ev*.25/.94);
  if(s.ev>0)near((s.socAfter-s.soc)*s.capacity/100,s.ev*.25*.94);
 }
 if(scenario==='offline')assert.deepEqual(r.eligibleTelemetry,['A']);
 if(r.blocked)assert.equal(r.commandCheck.ok,false);
 if(r.target!==null)near(r.unmet,Math.max(0,r.total-r.target));
}
const normal=M.run();near(normal.total,40);
const v1g=M.run({scenario:'support',v2g:false,exportAllowed:true});near(v1g.total,10);near(v1g.unmet,12);
const restricted=M.run({scenario:'support'});near(restricted.total,0);near(restricted.unmet,2);
const injection=M.run({scenario:'support',exportAllowed:true});near(injection.total,-2);near(injection.unmet,0);near(injection.sites[1].grid,-2);
const local=M.run({scenario:'congestion'});near(local.sites[0].grid,20);near(local.sites[1].grid,16);
const c={id:'new',authenticated:true,authorized:true,expires:20,power:5};
const ctx={now:10,seen:new Set(),telemetryFresh:true,gridPresent:true,lo:-6,hi:22};
assert.equal(M.validateCommand(c,ctx).ok,true);
assert.deepEqual(M.validateCommand(c,ctx),{ok:false,reason:'replay-or-expired'});
const attacks=[['identity',{authenticated:false},{}],['authorization',{authorized:false},{}],['replay-or-expired',{expires:10},{}],['replay-or-expired',{expires:10000},{}],['replay-or-expired',{}, {seen:new Set(['new'])}],['stale',{}, {telemetryFresh:false}],['islanding',{power:-1},{gridPresent:false}],['islanding',{power:5},{gridPresent:false}],['limits',{power:100},{}],['limits',{power:NaN},{}]];
for(const [reason,cmd,context] of attacks)assert.deepEqual(M.validateCommand({...c,...cmd},{...ctx,seen:new Set(),...context}),{ok:false,reason});
console.log(JSON.stringify({status:'PASS',parameterCases:cases,attackCases:attacks.length,referenceCases:5,scope:'modèle pédagogique et politique de commande, aucun équipement réel'},null,2));
