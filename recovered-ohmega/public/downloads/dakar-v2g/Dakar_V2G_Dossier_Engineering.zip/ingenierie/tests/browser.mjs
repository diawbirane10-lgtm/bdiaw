import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url);
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const binary=process.env.CHROMIUM_PACKAGE? (await import(pathToFileURL(process.env.CHROMIUM_PACKAGE))).default:null;
const browser=await chromium.launch(binary?{executablePath:await binary.executablePath(),args:binary.args,headless:true}:{headless:true});
await mkdir(path.join(root,'evidence'),{recursive:true});
let interactions=0;const errors=[],requests=[];
const context=await browser.newContext({acceptDownloads:true,reducedMotion:'reduce'});
const page=await context.newPage();
page.on('pageerror',e=>errors.push(e.message));
page.on('request',r=>{if(!r.url().startsWith('file:')&&!r.url().startsWith('blob:'))requests.push(r.url());});
await page.goto(pathToFileURL(path.join(root,'../Dakar_V2G_Architecture_Revisee.html')).href);
await page.locator('#tab-system').click();
assert.equal(await page.locator('#total').innerText(),'40 kW');
const viewports=[[1440,900],[1280,800],[1024,768],[820,1180],[768,1024],[430,932],[390,844],[360,800],[320,700]];
for(const [width,height] of viewports){
 await page.setViewportSize({width,height});
 for(const id of ['system','review','map','proof']){
  await page.locator('#tab-'+id).click();interactions++;
  assert.equal(await page.locator('#'+id).isVisible(),true);
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`Débordement ${width}/${id}`);
 }
 await page.locator('#tab-system').click();
 for(const scenario of await page.locator('#scenario option').evaluateAll(o=>o.map(x=>x.value))){await page.selectOption('#scenario',scenario);interactions++;assert.equal(await page.locator('#eventTitle').innerText(),await page.locator('#scenario option:checked').innerText());}
}
await page.setViewportSize({width:1440,height:900});
await page.selectOption('#scenario','support');
await page.check('#exportAllowed');
assert.equal(await page.locator('#total').innerText(),'-2 kW');
assert.equal(await page.locator('#unmet').innerText(),'0 kW');
await page.uncheck('#v2g');assert.equal(await page.locator('#total').innerText(),'10 kW');
await page.check('#v2g');
await page.locator('#reserve').evaluate(e=>{e.value='90';e.dispatchEvent(new Event('input',{bubbles:true}));});assert.equal(await page.locator('#total').innerText(),'10 kW');
await page.locator('#reserve').evaluate(e=>{e.value='60';e.dispatchEvent(new Event('input',{bubbles:true}));});
for(const layer of ['data','cyber','energy']){await page.locator(`[data-layer="${layer}"]`).click();assert.equal(await page.locator(`[data-layer="${layer}"]`).getAttribute('aria-pressed'),'true');interactions++;}
await page.locator('.node[data-key="pcc"]').first().click();assert.match(await page.locator('#inspectTitle').innerText(),/Raccordement/);
await page.selectOption('#equipment','ems');assert.match(await page.locator('#inspectTitle').innerText(),/Contrôleur local/);
await page.locator('#animate').click();assert.equal(await page.locator('#topology').evaluate(e=>getComputedStyle(e.querySelector('.wire')).animationName),'none');
const downloadPromise=page.waitForEvent('download');await page.locator('#exportCase').click();const download=await downloadPromise;
const dest=path.join(root,'evidence/exported-case.json');await download.saveAs(dest);assert.equal(JSON.parse(await readFile(dest,'utf8')).total,-2);
await page.selectOption('#scenario','outage');assert.equal(await page.locator('#total').innerText(),'0 kW');await page.check('#backup');assert.match(await page.locator('#eventText').innerText(),/3,2 h/);
for(const s of ['identity','replay','unsafe']){await page.selectOption('#scenario',s);assert.equal(await page.evaluate(()=>lastResult.commandCheck.ok),false);}
await page.locator('#tab-system').focus();await page.keyboard.press('ArrowRight');assert.equal(await page.locator('#tab-review').getAttribute('aria-selected'),'true');await page.keyboard.press('End');assert.equal(await page.locator('#tab-proof').getAttribute('aria-selected'),'true');
await page.locator('#tab-map').click();
const geo={type:'FeatureCollection',features:[{type:'Feature',properties:{name:'<img src=x onerror=alert(1)>'},geometry:{type:'Point',coordinates:[-17.43,14.68]}},{type:'Feature',properties:{},geometry:{type:'Polygon',coordinates:[[[-17.4,14.72],[-17.39,14.72],[-17.39,14.73],[-17.4,14.72]]]}}]};
await page.locator('#geoFile').setInputFiles({name:'test.geojson',mimeType:'application/geo+json',buffer:Buffer.from(JSON.stringify(geo))});
await page.waitForFunction(()=>document.querySelector('#mapStatus').textContent.startsWith('Import local'));
assert.equal(await page.locator('#geomap .geopoint').count(),1);assert.equal(await page.locator('#geomap img').count(),0);
await page.locator('#geoFile').setInputFiles({name:'bad.geojson',mimeType:'application/json',buffer:Buffer.from('{"type":"FeatureCollection","features":[]}')});
await page.waitForFunction(()=>document.querySelector('#mapStatus').textContent.startsWith('Import refusé'));
assert.equal(await page.locator('#geomap .geopoint').count(),1); // Échec d’import : ancienne couche préservée.
await page.locator('#clearGeo').click();assert.equal(await page.locator('#geomap .geopoint').count(),0);
for(const b of await page.locator('[data-gate]').all())await b.check();assert.match(await page.locator('#gateResult').innerText(),/6\/6 déclarées/);
await page.locator('#tab-review').click();await page.locator('[data-source="S01"]').click();assert.equal(await page.locator('#proof').isVisible(),true);
await page.screenshot({path:path.join(root,'evidence/sources.png'),fullPage:true});
await page.locator('#tab-map').click();await page.evaluate(()=>{document.activeElement?.blur();window.scrollTo(0,0);});await page.screenshot({path:path.join(root,'evidence/map.png'),fullPage:true});
await page.locator('#tab-system').click();await page.selectOption('#scenario','normal');await page.uncheck('#backup');await page.uncheck('#exportAllowed');await page.selectOption('#equipment','ems');
await page.evaluate(()=>{document.activeElement?.blur();window.scrollTo(0,0);});
await page.screenshot({path:path.join(root,'evidence/desktop.png'),fullPage:true});
await page.setViewportSize({width:390,height:844});await page.evaluate(()=>window.scrollTo(0,0));await page.screenshot({path:path.join(root,'evidence/mobile.png'),fullPage:true});
await page.emulateMedia({media:'print'});assert.equal(await page.locator('#review').isVisible(),true);assert.equal(await page.locator('#proof').isVisible(),true);await page.pdf({path:path.join(root,'evidence/print-check.pdf'),format:'A4',printBackground:true});
assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
const report={status:'PASS',browser:await browser.version(),viewports,scenarioViewportChecks:90,tabViewportChecks:36,additionalChecks:['V1G/V2G','reserve','layers','equipment','reducedMotion','JSONdownload','outage','threeCommandGuards','keyboardTabs','GeoJSONvalidInvalidXSS','gateChecklist','sourceNavigation','printCSS'],externalRequests:requests.length,pageErrors:errors,notes:'Fond OSM externe volontairement non chargé : disponibilité en ligne non vérifiée.'};
await writeFile(path.join(root,'evidence/browser-results.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();
