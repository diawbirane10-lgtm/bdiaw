import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url),root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const binary=process.env.CHROMIUM_PACKAGE?(await import(pathToFileURL(process.env.CHROMIUM_PACKAGE))).default:null;
const browser=await chromium.launch(binary?{executablePath:await binary.executablePath(),args:binary.args,headless:true}:{headless:true});
const context=await browser.newContext({acceptDownloads:true,reducedMotion:'reduce',viewport:{width:1440,height:900}}),page=await context.newPage();
const errors=[],requests=[],checks=[];
page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(!r.url().startsWith('file:')&&!r.url().startsWith('blob:'))requests.push(r.url());});
const state=()=>page.evaluate(()=>({time:Simulator.engine.time,frame:Simulator.engine.frame,report:Simulator.engine.report(),running:Simulator.running,yaw:Simulator.scene.yaw,positions:Simulator.scene.positions}));
const range=async(id,value)=>page.locator(id).evaluate((e,v)=>{e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));},String(value));
const reset=()=>page.locator('#simReset').click();
await page.goto(pathToFileURL(path.join(root,'../Dakar_V2G_Architecture_Revisee.html')).href);
await page.waitForFunction(()=>window.Simulator?.engine);
assert.equal(await page.locator('#sim').isVisible(),true);assert.equal((await state()).time,0);
assert.ok(await page.locator('#simScene [data-object="charger"]').count()>0);
await page.locator('#sim').screenshot({path:path.join(root,'evidence/simulator-desktop.png')});
// Native scene controls, object inspection, pointer orbit, keyboard and placement.
const yaw=(await state()).yaw;await page.locator('#sceneRight').click();assert.ok((await state()).yaw>yaw);
await page.locator('#simScene').focus();await page.keyboard.press('ArrowRight');assert.ok((await state()).yaw>yaw+.2);
const box=await page.locator('#simScene').boundingBox();await page.mouse.move(box.x+box.width*.8,box.y+box.height*.6);await page.mouse.down();await page.mouse.move(box.x+box.width*.9,box.y+box.height*.66,{steps:5});await page.mouse.up();assert.ok((await state()).yaw>yaw+.3);
await page.locator('#sceneReset').click();assert.equal((await state()).yaw,yaw);
await page.locator('#simScene [data-object="charger"]').first().focus();await page.keyboard.press('Enter');assert.match(await page.locator('#simInspectTitle').innerText(),/Borne/);
await page.locator('#scenePlacement summary').click();const beforeMove=(await state()).report;await range('#sceneX',4);assert.equal((await state()).positions.A[0],4);assert.deepEqual((await state()).report,beforeMove);
await page.selectOption('#sceneSite','B');assert.match(await page.locator('#simScene').textContent(),/SITE B/);await range('#sceneZ',3);assert.equal((await state()).positions.B[1],3);
await page.selectOption('#sceneSite','A');await page.locator('#sceneTop').click();await range('#sceneZoom',1.2);await page.locator('#sceneReset').click();checks.push('3D rotation / glisser / clavier / sélection / deux sites / placement indépendant');
// Live run, pause and exactly one minute advancement.
await page.locator('#simPlay').click();await page.waitForFunction(()=>Simulator.engine.time>=60);await page.locator('#simPlay').click();const paused=(await state()).time;assert.ok(paused>0);await page.waitForTimeout(450);assert.equal((await state()).time,paused);assert.equal(await page.locator('#simDuration').isDisabled(),true);
await page.locator('#simStep').click();assert.equal((await state()).time,paused+60);checks.push('Lecture / pause / pas de 60 s / configuration verrouillée');
// History preview does not rewind physical model.
const current=(await state()).time;await range('#simSeek',0);assert.equal((await state()).time,current);assert.match(await page.locator('#simRunStatus').innerText(),/Relecture/);assert.match(await page.locator('#simElapsed').innerText(),/^0 /);await page.locator('#simStep').click();assert.equal((await state()).time,current+60);checks.push('Relecture sans réécriture du passé');
// Events, cyber rejects and current topology linked to physical state.
await reset();await page.selectOption('#simPreset','empty');await page.selectOption('#simEvent','gridOff');await page.locator('#simInject').click();assert.equal((await state()).frame.island,false);await page.locator('#simStep').click();let s=await state();assert.equal(s.frame.island,true);assert.equal(s.frame.total,0);assert.ok(s.report.metrics.unservedKWh>0);
await page.locator('[data-sim-layer="energy"]').click();assert.match(await page.locator('#simTopology').textContent(),/isol|coupure|arrêt/i);
await page.selectOption('#simEvent','identity');await page.locator('#simInject').click();await page.locator('#simStep').click();assert.equal((await state()).report.metrics.rejected,1);
await page.selectOption('#simEvent','wanOff');await page.locator('#simInject').click();await page.locator('#simStep').click();assert.equal((await state()).frame.sites[1].wan,false);assert.match(await page.locator('#simSites').innerText(),/Dernier PCC reçu/);
for(const layer of ['data','cyber','3d']){await page.locator(`[data-sim-layer="${layer}"]`).click();assert.equal(await page.locator(`[data-sim-layer="${layer}"]`).getAttribute('aria-pressed'),'true');}
await page.selectOption('#simEvent','gridOn');await page.locator('#simEventAt').fill('10');await page.locator('#simSchedule').click();assert.ok((await state()).report.events.some(e=>e.at===10&&e.type==='gridOn'));
await page.locator('.eventcontrol details summary').click();await page.locator('[data-remove-event]').last().click();assert.equal((await state()).report.events.some(e=>e.at===10&&e.type==='gridOn'),false);
await page.locator('#simEventAt').fill('0');await page.locator('#simSchedule').click();assert.match(await page.locator('#simEventFeedback').innerText(),/refusé/);checks.push('Coupure / WAN / rejet cyber / couches / programmation et retrait / passé refusé');
// Identical scenario, V1G vs V2G, real downloads.
await reset();await page.selectOption('#simPreset','support');await page.locator('#simExport').check();await page.locator('#simV2g').uncheck();await page.locator('#simFinish').click();const v1g=(await state()).report;assert.equal(v1g.metrics.dischargeKWh,0);await page.locator('#simSaveRun').click();
await reset();await page.locator('#simV2g').check();await page.locator('#simFinish').click();const v2g=(await state()).report;assert.ok(v2g.metrics.dischargeKWh>0);assert.ok(v2g.metrics.unmetKWh<v1g.metrics.unmetKWh);await page.locator('#simSaveRun').click();assert.match(await page.locator('#simCompareNote').innerText(),/Conditions identiques/);assert.equal(await page.locator('#simCompareRows tr').count(),10);
await page.locator('[data-chart="soc"]').click();assert.match(await page.locator('#simChartLegend').textContent(),/Véhicule A/);assert.ok(await page.locator('#simChart path').count()>10);await page.locator('[data-chart="power"]').click();
for(const [button,ext] of [['#simJson','json'],['#simCsv','csv']]){const promise=page.waitForEvent('download');await page.locator(button).click();const dl=await promise,p=path.join(root,'evidence/temporal-export.'+ext);await dl.saveAs(p);const txt=await readFile(p,'utf8');if(ext==='json'){const j=JSON.parse(txt);assert.equal(j.metrics.dischargeKWh,v2g.metrics.dischargeKWh);assert.equal(j.comparison.length,2);assert.equal(j.plan3D.geographicValidation,false);}else{assert.match(txt,/total_kW/);assert.equal(txt.trim().split('\n').length,v2g.history.length+1);}}
checks.push('V1G / V2G mêmes conditions / comparaison / courbes / exports JSON et CSV');
// Different transport speeds, same engine endpoint.
await reset();await page.selectOption('#simSpeed','120');await page.locator('#simPlay').click();await page.waitForFunction(()=>Simulator.engine.done,{timeout:15000});assert.deepEqual((await state()).report,v2g);checks.push('Vitesse lecture indépendante du résultat énergétique');
// Backup exhaustion and UI reset.
await reset();await page.selectOption('#simPreset','backup');await page.locator('#simFinish').click();s=await state();assert.equal(s.time,21600);assert.ok(s.frame.sites.every(x=>Math.abs(x.bessSoc-40)<1e-7));assert.ok(s.report.metrics.criticalUnservedKWh>0);await page.locator('#sim').screenshot({path:path.join(root,'evidence/simulator-outage.png')});checks.push('Épuisement secours et énergie critique non servie');
await reset();assert.equal((await state()).time,0);assert.equal(await page.locator('#simDuration').isDisabled(),false);
const viewports=[[1440,900],[1280,800],[1024,768],[820,1180],[768,1024],[430,932],[390,844],[360,800],[320,700],[844,390]];
let responsiveChecks=0;for(const [width,height]of viewports){await page.setViewportSize({width,height});for(const layer of ['3d','energy','data','cyber']){await page.locator(`[data-sim-layer="${layer}"]`).click();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`Débordement ${width}/${layer}`);responsiveChecks++;}}
await page.setViewportSize({width:390,height:844});await page.locator('[data-sim-layer="3d"]').click();await page.locator('#sim').screenshot({path:path.join(root,'evidence/simulator-mobile.png')});
assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
const report={status:'PASS',browser:await browser.version(),checks,viewports,responsiveChecks,pageErrors:errors,externalRequests:requests.length,scope:'Simulation énergétique et plan 3D illustratif. Pas de matériel, ni étude physique, ni fond OSM en ligne testé.'};
await writeFile(path.join(root,'evidence/simulation-browser-results.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();
