const assert=require('node:assert/strict');
global.EnergyModel=require('../model.js');const T=require('../simulation-model.js');
const near=(a,b,tol=1e-7)=>assert.ok(Math.abs(a-b)<tol,`${a} != ${b}`);
let sequences=0,steps=0;
function check(e){
 const f=e.frame,m=e.metrics;near(f.total,f.sites.reduce((n,s)=>n+s.grid,0));
 for(const s of f.sites){near(s.grid+s.usedPv+s.bess,s.servedLoad+s.ev);assert.ok(s.grid<=s.importLimit+1e-7);assert.ok(s.grid>=-(e.config.exportAllowed?15:0)-1e-7);assert.ok(s.socAfter>=-1e-7&&s.socAfter<=100+1e-7);assert.ok(s.bessSoc>=40-1e-7);if(s.ev<0)assert.ok(s.socAfter>=s.reserve-1e-7);if(!s.available)near(s.ev,0);if(f.island){near(s.grid,0);near(s.ev,0);near(s.usedPv,0);}assert.ok(s.servedLoad<=s.requestedLoad+1e-7);}
 near(m.importKWh+m.pvKWh+m.dischargeKWh+m.bessKWh,m.servedLoadKWh+m.chargeKWh+m.exportKWh);
 near(m.requestedLoadKWh,m.servedLoadKWh+m.unservedKWh);
 near(e.sites.reduce((n,s)=>n+s.energy-s.initialEnergy,0),m.chargeKWh*.94-m.dischargeKWh/.94);
 near(e.sites.reduce((n,s)=>n+s.bessInitial-s.bessEnergy,0),m.bessKWh/.9);
 assert.ok(m.conversionLossKWh>=-1e-8);steps++;
}
const policies=[];for(const v2g of [false,true])for(const exportAllowed of [false,true])for(const backup of [false,true])for(const reserve of [20,60,90])policies.push({v2g,exportAllowed,backup,reserve});
for(const opts of policies)for(const preset of ['mixed','support','backup','departure']){
 const e=new T.Engine({...opts,duration:preset==='backup'?360:240},T.presets[preset]);while(!e.done){e.step();check(e);}sequences++;
}
// Décharge longue : énergie finie, secours total 2 × 12 × (0,70 − 0,40) × 0,90 = 6,48 kWh.
const off=new T.Engine({profile:false,duration:360,backup:true},[{at:0,type:'gridOff'}]);off.finish();near(off.metrics.bessKWh,6.48);near(off.metrics.importKWh,0);near(off.sites[0].bessEnergy,4.8);assert.ok(off.metrics.criticalUnservedKWh>5);
// 10 min de charge non contrainte : formule DC indépendante, 22 kW × 10/60 × 0,94.
const linear=new T.Engine({profile:false,pv:false,socA:0,socB:0,reserve:0,targetSoc:100,departureA:600,departureB:600},[]);linear.advance(600);near(linear.sites[0].energy,22*10/60*.94);
// Déterminisme et découpage d'exécution : lecture rapide et pas successifs ne changent pas les résultats.
const a=new T.Engine({},T.presets.mixed),b=new T.Engine({},T.presets.mixed);a.finish();while(!b.done)b.advance(60);assert.deepEqual(a.report(),b.report());
// Attaques isolées : pas de perturbation du bilan physique, rejet effectif dans la fonction de garde.
const plain=new T.Engine({duration:30,profile:false},[]),attack=new T.Engine({duration:30,profile:false},[{at:1,type:'unsafe'},{at:2,type:'identity'},{at:3,type:'replay'}]);plain.finish();attack.finish();near(plain.metrics.chargeKWh,attack.metrics.chargeKWh);near(plain.metrics.importKWh,attack.metrics.importKWh);assert.equal(attack.metrics.rejected,3);
// Départ anticipé : aucun véhicule remplacé gratuitement, déficit déclaré et puissance ensuite nulle.
const depart=new T.Engine({duration:30,socB:0,pv:false},[{at:1,type:'depart',site:'B'}]);depart.finish();assert.equal(depart.sites[1].present,false);assert.ok(depart.report().metrics.departureDeficitKWh>40);near(depart.frame.sites[1].ev,0);
// Puissance insuffisante et PV très élevé : délestage/écrêtage conservatifs au lieu de violer les limites.
const tight=new T.Engine({duration:30,profile:false,importA:1,loadA:50,pv:false},[]);tight.finish();assert.ok(tight.metrics.unservedKWh>20);check(tight);
const surplus=new T.Engine({duration:30,profile:false,pvA:50,pvB:50,loadA:0,loadB:0,socA:100,socB:100,exportAllowed:false},[]);surplus.finish();near(surplus.metrics.exportKWh,0);assert.ok(surplus.metrics.curtailedKWh>45);check(surplus);
// Retour du véhicule conserve son énergie ; perte WAN retire la télémesure et la consigne collective.
const lost=new T.Engine({duration:30},[{at:0,type:'flexOn'},{at:1,type:'wanOff',site:'B'}]);lost.advance(120);assert.deepEqual(lost.frame.eligibleTelemetry,['A']);assert.ok(lost.frame.sites[1].telemetryAge>=55);assert.ok(lost.frame.sites[1].ev>=0);
const ret=new T.Engine({duration:30},[{at:0,type:'depart',site:'A'},{at:10,type:'arrive',site:'A'}]);ret.advance(600);near(ret.sites[0].energy,ret.sites[0].initialEnergy);ret.advance(60);assert.ok(ret.sites[0].energy>ret.sites[0].initialEnergy);
const endEvent=new T.Engine({duration:30},[{at:30,type:'gridOff'}]);endEvent.finish();assert.equal(endEvent.frame.island,true);
// Effet fonctionnel réel de V2G : une réserve respectée doit autoriser la décharge.
const v1=new T.Engine({v2g:false,exportAllowed:true},T.presets.support),v2=new T.Engine({v2g:true,exportAllowed:true},T.presets.support);v1.finish();v2.finish();near(v1.metrics.dischargeKWh,0);assert.ok(v2.metrics.dischargeKWh>0);assert.ok(v2.metrics.unmetKWh<v1.metrics.unmetKWh);
console.log(JSON.stringify({status:'PASS',sequenceCount:sequences,invariantStepChecks:steps,stepSeconds:5,additionalTests:11,scope:'énergie/contrôle pédagogique, aucune preuve physique'},null,2));
