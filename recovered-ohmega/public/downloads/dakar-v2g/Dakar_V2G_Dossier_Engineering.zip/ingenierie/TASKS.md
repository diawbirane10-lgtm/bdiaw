# Tâches contrôlées R1

| ID | Tâche | Rôle séquentiel | Condition et preuve | État |
| --- | --- | --- | --- | --- |
| TSK-001 | État de l’art et données primaires | Recherche | SOURCES.md et inventaire, limites explicites | TERMINÉ |
| TSK-002 | Revue contradictoire et correction d’architecture | Systèmes/énergie/contrôle/cyber/SIG/exploitation/économie | 13 objections, décisions et risques | TERMINÉ |
| TSK-003 | Modèle et page standalone | Production logiciel | Conservation/limites, TST-001 | TERMINÉ |
| TSK-004 | Contre-vérification navigateur et inspection visuelle | Évaluation | TST-002 final PASS, captures | TERMINÉ |
| TSK-005 | Dossier de concept et provenance | Configuration | Manifeste, source, README et inventaire | TERMINÉ |
| TSK-R01 | Collecte flotte/site et raccordement | Porteur et institutions | Profils terrain et étude, REQ-R01/R05 | À FAIRE |
| TSK-R02 | Essai du couple bidirectionnel | Fournisseur et laboratoire | REQ-R02 | À FAIRE |
| TSK-R03 | Vérification indépendante de l’installation | Ingénierie habilitée | Sûreté/cyber/protections/conformité | À FAIRE |

Chemin critique : usage et site → raccordement et couple compatible → banc d’essai → autorisations/instrumentation → pilote mesuré → décision multisite. L’extension ne commence pas sur des données manquantes.


## Extension R2 — 10 octobre 2026

TSK-S01 — modèle temporel / événements / énergie : TERMINÉ, TST-S01 PASS.
TSK-S02 — lecture, graphiques, journaux et comparaison/export : TERMINÉ, TST-S02 PASS.
TSK-S03 — scène 3D et position illustrative : TERMINÉ, AC-S08 PASS.
TSK-S04 — contre-vérification et régressions : TERMINÉ, EV-S01/02/03/04.
TSK-S05 — assemblage et mise à jour des fichiers : contenu prêt et contrôlé ; remise après sauvegarde.
Tâches terrain R1 inchangées.


2026-10-10 — TSK-S05 TERMINÉ pour l’assemblage : archive contrôlée, manifeste et reconstruction TST-S03 PASS.
