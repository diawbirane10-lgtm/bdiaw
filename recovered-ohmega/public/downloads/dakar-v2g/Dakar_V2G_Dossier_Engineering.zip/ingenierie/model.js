/* Modèle pédagogique quasi-statique AC : aucun protocole industriel implémenté. */
'use strict';
const EnergyModel = (() => {
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const specs=[{id:'A',load:12,pv:6,normal:18,soc:70,capacity:60},{id:'B',load:8,pv:4,normal:12,soc:80,capacity:60}];
 const scenarios={normal:'Recharge normale',support:'Demande de flexibilité',outage:'Coupure électrique',offline:'Internet perdu au site B',absent:'Véhicule B absent',reserve:'Réserve de départ atteinte',identity:'Identité non reconnue',replay:'Commande rejouée',unsafe:'Commande authentifiée excessive',congestion:'Contrainte locale au site A'};
 function run(input={}) {
  const o={scenario:'normal',pv:true,v2g:true,exportAllowed:false,backup:false,reserve:60,target:-2,...input};
  o.reserve=clamp(Number(o.reserve)||0,0,100);o.target=clamp(Number(o.target)||0,-4,40);
  const island=o.scenario==='outage', support=['support','absent','reserve'].includes(o.scenario);
  const sites=specs.map(s=>{
   const reserve=o.scenario==='reserve'?s.soc: o.reserve;
   const pv=o.pv?s.pv:0,available=!(o.scenario==='absent'&&s.id==='B');
   const importLimit=o.scenario==='congestion'&&s.id==='A'?20:40;
   const base=s.load-pv;
   const energyAbove=Math.max(0,(s.soc-reserve)/100*s.capacity);
   // 15 min; rendement batterie vers AC 94 %. Limite basse au PCC indépendante de la borne.
   const discharge=o.v2g&&available?Math.min(6,energyAbove*.94/.25):0;
   const lo=Math.max(-discharge,(o.exportAllowed?-15:0)-base);
   const hi=Math.min(22,importLimit-base,(100-s.soc)/100*s.capacity/.25/.94);
   return {...s,pv,reserve,available,base,importLimit,lo,hi,ev:available?clamp(s.normal,lo,hi):0,grid:0};
  });
  const events=[],blocked=['identity','replay','unsafe'].includes(o.scenario);
  let commandCheck=null;
  if(blocked){
   const c={id:o.scenario==='replay'?'seen':'new',authenticated:o.scenario!=='identity',authorized:true,expires:20,power:o.scenario==='unsafe'?100:5};
   commandCheck=validateCommand(c,{now:10,seen:new Set(['seen']),telemetryFresh:true,gridPresent:true,lo:sites[0].lo,hi:sites[0].hi});
  }
  if(support){
   // V1G d'abord : réduire la charge, puis utiliser seulement la décharge nécessaire.
   let excess=sites.reduce((a,s)=>a+s.base+s.ev,0)-o.target;
   for(const s of sites){let d=Math.min(Math.max(0,excess),Math.max(0,s.ev));s.ev-=d;excess-=d;}
   for(const s of [...sites].reverse()){let d=s.available?Math.min(Math.max(0,excess),Math.max(0,s.ev-s.lo)):0;s.ev-=d;excess-=d;}
   events.push('V1G prioritaire, puis décharge selon réserve, consentement supposé et limites du raccordement.');
  }
  if(o.scenario==='offline')events.push('Site B : aucune nouvelle consigne distante ; stratégie locale de recharge bornée. La flexibilité B est retirée des engagements centraux.');
  if(o.scenario==='identity')events.push('REFUS simulé : identité inconnue. Une implémentation réelle vérifierait certificat et autorisations côté contrôleur.');
  if(o.scenario==='replay')events.push('REFUS simulé : identifiant déjà vu ou validité expirée. Journalisation et traitement local.');
  if(o.scenario==='unsafe')events.push('REFUS simulé : demande de charge de 100 kW au site A, au-delà des limites locales. Une authentification valide ne rend pas une consigne sûre.');
  if(o.scenario==='congestion')events.push('Site A plafonné à 20 kW au PCC. La puissance disponible au site B ne change pas cette limite locale.');
  if(island)events.push(o.backup?'PCC isolé ; recharge suspendue. Variante avec batterie grid-forming et protections étudiées : seuls 1 kW de services critiques sont alimentés par site.':'PCC isolé ; recharge suspendue. UPS auxiliaire pour contrôle seulement, autonomie à dimensionner ; aucun secours de puissance simulé.');
  for(const s of sites){
   s.ev=island?0:s.ev;
   s.grid=island?0:s.base+s.ev;
   s.servedLoad=island?(o.backup?1:0):s.load;
   s.usedPv=island?0:s.pv; // hypothèse conservatrice, PV arrêté dans cette variante.
   s.bess=island&&o.backup?1:0;
   s.socAfter=clamp(s.soc+(s.ev>=0?s.ev*.94:s.ev/.94)*.25/s.capacity*100,0,100);
   s.mode=s.ev<-.001?'Décharge':s.ev>.001?'Recharge':'Pause';
   s.headroom=Math.max(0,s.importLimit-s.grid);
  }
  const total=sites.reduce((a,s)=>a+s.grid,0), baseline=specs.reduce((a,s)=>a+s.load-(o.pv?s.pv:0)+s.normal,0);
  const unmet=support?Math.max(0,total-o.target):0;
  const autonomy=island&&o.backup?12*(.70-.40)*.90/1:0;
  return {options:o,sites,total,baseline,reduction:baseline-total,unmet,island,blocked,commandCheck,events,autonomy,target:support?o.target:null,eligibleTelemetry:o.scenario==='offline'?['A']:['A','B']};
 }
 function validateCommand(c,context){
  if(c.authenticated!==true)return {ok:false,reason:'identity'};
  if(c.authorized!==true)return {ok:false,reason:'authorization'};
  if(typeof c.id!=='string'||!c.id||!Number.isFinite(context.now)||!Number.isFinite(c.expires)||context.now>=c.expires||c.expires-context.now>15||context.seen.has(c.id))return {ok:false,reason:'replay-or-expired'};
  if(!context.telemetryFresh)return {ok:false,reason:'stale'};
  if(!context.gridPresent&&c.power!==0)return {ok:false,reason:'islanding'};
  if(!Number.isFinite(c.power)||c.power<context.lo||c.power>context.hi)return {ok:false,reason:'limits'};
  context.seen.add(c.id);
  return {ok:true,reason:'accepted'};
 }
 return {run,validateCommand,scenarios};
})();
if(typeof module!=='undefined') module.exports=EnergyModel;
