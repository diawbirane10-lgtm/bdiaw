'use strict';
let simEngine,simTimer=null,simRunning=false,simLayer='3d',simChartMode='power',simPreview=null,savedRuns=[],simPendingSeconds=0;
const scene=new SiteScene($('#simScene'),key=>simInspect(key));
const timeText=t=>{const m=Math.floor(t/60),h=Math.floor((simEngine.config.startHour*60+m)/60)%24;return String(h).padStart(2,'0')+':'+String(m%60).padStart(2,'0');};
const simFields={duration:'simDuration',target:'simTarget',reserve:'simReserve',socA:'simSocA',socB:'simSocB',importA:'simImportA',importB:'simImportB',loadA:'simLoadA',loadB:'simLoadB',pvA:'simPvA',pvB:'simPvB',departureA:'simDepartA',departureB:'simDepartB',targetSoc:'simGoal'};
function simConfig(){const c={};for(const [key,id]of Object.entries(simFields)){const e=document.getElementById(id);if(!e.checkValidity()||e.value==='')throw Error('Vérifiez le paramètre : '+e.labels[0].textContent);c[key]=Number(e.value);}for(const [key,id]of Object.entries({v2g:'simV2g',exportAllowed:'simExport',pv:'simPv',backup:'simBackup'}))c[key]=$('#'+id).checked;return c;}
function simReset(){
 simPause();simPreview=null;simPendingSeconds=0;try{simEngine=new TemporalModel.Engine(simConfig(),TemporalModel.presets[$('#simPreset').value]);$('#simConfig').disabled=false;$('#simGoal').value=simEngine.config.targetSoc;$('#simPlay').disabled=false;$('#simStep').disabled=false;$('#simFinish').disabled=false;simRender();}catch(e){$('#simRunStatus').textContent=e.message;$('#simPlay').disabled=true;$('#simStep').disabled=true;$('#simFinish').disabled=true;}
}
function simPause(){if(simTimer!==null)clearInterval(simTimer);simTimer=null;simRunning=false;$('#simPlay').textContent='▶ Lancer';$('#simTopology').classList.remove('simrunning');}
function simPlay(){
 if(simRunning){simPause();simRender();return;}if(simEngine.done)return;
 simPreview=null;simRunning=true;$('#simConfig').disabled=true;$('#simPlay').textContent='Ⅱ Pause';$('#simTopology').classList.add('simrunning');
 simTimer=setInterval(()=>{try{simPendingSeconds+=Number($('#simSpeed').value)*60*.2;const ticks=Math.floor(simPendingSeconds/5)*5;simPendingSeconds-=ticks;simEngine.advance(ticks);if(simEngine.done)simPause();simRender();}catch(e){simPause();$('#simRunStatus').textContent='Calcul arrêté : '+e.message;}},200);simRender();
}
function simInspect(key){selected=key;const v=info[key]||info.ems;$('#simInspectTitle').textContent=v[0];$('#simInspectText').textContent=v[1];$('#simEquipment').value=key;$$('#simTopology .node').forEach(n=>n.classList.toggle('selected',n.dataset.key===key));}
function simView(){const f=simPreview===null?simEngine.frame:simEngine.history[simPreview];$('#simScene').hidden=simLayer!=='3d';$('#simTopology').hidden=simLayer==='3d';$('#sceneControls').hidden=simLayer!=='3d';$('#scenePlacement').hidden=simLayer!=='3d';$('#sceneHint').hidden=simLayer!=='3d';if(simLayer==='3d'){scene.render(f);$('#simLayerTitle').textContent='Plan de site illustratif · volumes 3D';}else{renderTopology(f,simLayer,'simTopology','simLayerTitle',simInspect);}}
function simRender(){
 const f=simPreview===null?simEngine.frame:simEngine.history[simPreview],m=f.metrics;
 $('#simRunStatus').textContent=simPreview!==null?'Relecture · calcul conservé':simEngine.done?'Essai terminé':simRunning?'Calcul en cours':simEngine.time?'En pause':'Prêt · essai non lancé';
 $('#simClock').textContent=timeText(f.time);$('#simElapsed').textContent=`${fmt(f.time/60)} / ${simEngine.config.duration} min`;
 $('#simPower').textContent=fmt(f.total)+' kW';$('#simDirection').textContent=f.island?'Raccordements isolés':f.total<-.001?'Injection nette calculée':'Import net calculé';
 $('#simChargeEnergy').textContent=fmt(m.chargeKWh)+' kWh';$('#simUnserved').textContent=fmt(m.unservedKWh)+' kWh';$('#simCritical').textContent='Critique : '+fmt(m.criticalUnservedKWh)+' kWh';
 $('#simUnmet').textContent=f.target===null?'—':fmt(f.unmet)+' kW';$('#simControlState').textContent=f.island?'Secours local / délestage':f.eligibleTelemetry.length<2?'Supervision partielle':f.target!==null?'Objectif : '+fmt(f.target)+' kW':'Recharge locale';
 $('#simReserveOut').textContent=fmt(simEngine.config.reserve)+' %';
 $('#simSites').innerHTML=f.sites.map(s=>`<article class="simsitecard"><h3>Site ${s.id}<span class="badge">${esc(s.mode)}</span></h3><div class="value">${fmt(s.grid)} <small>kW au PCC</small></div><div class="bar"><div class="level" style="width:${s.socAfter}%"></div><div class="floor" style="left:${Math.min(100,s.reserve)}%"></div></div><p><strong>Véhicule ${fmt(s.socAfter)} %</strong> · réserve ${fmt(s.reserve)} % · ${fmt(s.ev)} kW AC</p><p>${f.options.backup?'Batterie fixe '+fmt(s.bessSoc)+' % · secours '+fmt(s.bess)+' kW':'Secours fixe non installé'}</p><p>WAN ${s.wan?'disponible':'perdu'} · télémesure ${s.wan?'fraîche':`âgée de ${fmt(s.telemetryAge)} s`}</p>${!s.wan?`<p class="muted">Dernier PCC reçu : ${fmt(s.lastKnownPower)} kW. La puissance affichée en haut est le calcul physique, pas une mesure reçue.</p>`:''}</article>`).join('');
 $('#simSeek').max=simEngine.history.length-1;$('#simSeek').value=simPreview===null?simEngine.history.length-1:simPreview;$('#simSeekLabel').textContent=simPreview===null?'État courant':'Instant '+timeText(f.time)+' · '+fmt(f.time/60)+' min';
 if(document.activeElement!==$('#simEventAt'))$('#simEventAt').value=Math.ceil(simEngine.time/60);
 const r=simEngine.report(),n=(v,u)=>fmt(v)+' '+u;
 const rows=[['Achat réseau',n(r.metrics.importKWh,'kWh AC')],['Injection réseau',n(r.metrics.exportKWh,'kWh AC')],['Recharge véhicules',n(r.metrics.chargeKWh,'kWh AC')],['Décharge véhicules',n(r.metrics.dischargeKWh,'kWh AC')],['Solaire utilisé',n(r.metrics.pvKWh,'kWh AC')],['Solaire non utilisé',n(r.metrics.curtailedKWh,'kWh AC')],['Pertes de conversion',n(r.metrics.conversionLossKWh,'kWh')],['Pointe agrégée d’import',n(r.metrics.peakImport,'kW')],['Écart au service demandé',n(r.metrics.unmetKWh,'kWh')],['Besoin manquant aux départs',n(r.metrics.departureDeficitKWh,'kWh DC')],['Départs observés',String(r.metrics.departures)],['Commandes hostiles refusées',String(r.metrics.rejected)]];
 $('#simReport').innerHTML=rows.map(([a,b])=>`<dt>${a}</dt><dd>${b}</dd>`).join('');
 $('#simLogs').innerHTML=simEngine.logs.length?simEngine.logs.slice(-40).reverse().map(l=>`<div class="simlog ${l.type==='reject'?'reject':''}"><time>${timeText(l.time)} · t = ${fmt(l.time/60)} min</time>${esc(l.message)}</div>`).join(''):'<p class="small muted">Aucun événement appliqué.</p>';
 $('#simPlay').disabled=simEngine.done;$('#simStep').disabled=simRunning||simEngine.done;$('#simFinish').disabled=simRunning||simEngine.done;
 simView();simChart();simScheduleList();
}
function simScheduleList(){
 $('#eventCount').textContent='('+simEngine.events.length+')';
 $('#simScheduleList').innerHTML=simEngine.events.map((e,i)=>`<div class="scheduled ${e.done?'applied':''}"><span>${fmt(e.at)} min · ${esc(TemporalModel.labels[e.type])}${e.site!=='all'?' / '+e.site:''}${e.done?' ✓':''}</span>${!e.done?`<button data-remove-event="${i}" aria-label="Retirer ${esc(TemporalModel.labels[e.type])} à ${e.at} minutes">×</button>`:''}</div>`).join('')||'<p class="small muted">Programme vide. Ajoutez vos événements.</p>';
 $$('[data-remove-event]').forEach(b=>b.addEventListener('click',()=>{simEngine.events.splice(Number(b.dataset.removeEvent),1);simScheduleList();}));
}
function simChart(){
 const samples=simEngine.history,step=Math.max(1,Math.ceil(samples.length/350));const data=samples.filter((x,i)=>i%step===0||i===samples.length-1);
 const c=simEngine.config,W=920,H=275,L=52,R=16,T=18,B=40,x=t=>L+t/(c.duration*60)*(W-L-R);
 const series=simChartMode==='power'?[['PCC A','#006d68',f=>f.sites[0].grid],['PCC B','#995500',f=>f.sites[1].grid],['Total calculé','#142b32',f=>f.total],['Consigne','#76518c',f=>f.target]]:[['Véhicule A','#006d68',f=>f.sites[0].socAfter],['Véhicule B','#995500',f=>f.sites[1].socAfter],...(c.backup?[['Secours A','#76518c',f=>f.sites[0].bessSoc],['Secours B','#497d98',f=>f.sites[1].bessSoc]]:[])];
 const values=data.flatMap(f=>series.map(s=>s[2](f))).filter(v=>v!==null),min=simChartMode==='soc'?0:Math.min(0,...values)-3,max=simChartMode==='soc'?100:Math.max(10,...values)+4,y=v=>T+(max-v)/(max-min)*(H-T-B);
 let html=`<rect width="920" height="275" fill="white"/><text x="7" y="14" font-size="12">${simChartMode==='soc'?'SoC %':'kW'}</text>`;
 for(let i=0;i<=4;i++){const v=min+(max-min)*i/4,yy=y(v);html+=`<path d="M${L} ${yy}H${W-R}" stroke="#dce5df"/><text x="${L-7}" y="${yy+4}" text-anchor="end" font-size="11">${fmt(v)}</text>`;}
 for(let i=0;i<=4;i++){const t=c.duration*60*i/4;html+=`<text x="${x(t)}" y="${H-12}" text-anchor="middle" font-size="11">${fmt(t/60)} min</text>`;}
 for(const e of simEngine.events.filter(e=>e.done))html+=`<path d="M${x(e.at*60)} ${T}V${H-B}" stroke="#90aaa0" stroke-dasharray="2 4"><title>${esc(TemporalModel.labels[e.type])} · ${e.at} min</title></path>`;
 if(simChartMode==='soc')html+=`<path d="M${L} ${y(c.reserve)}H${W-R}" stroke="#73877d" stroke-dasharray="7 4"/><text x="${W-R-5}" y="${y(c.reserve)-4}" text-anchor="end" font-size="10">réserve initiale ${c.reserve} %</text>`;
 for(const [label,color,get]of series){let d='',active=false;for(const f of data){const v=get(f);if(v===null){active=false;continue;}d+=(active?'L':'M')+x(f.time).toFixed(2)+' '+y(v).toFixed(2)+' ';active=true;}html+=`<path d="${d}" fill="none" stroke="${color}" stroke-width="${label==='Total calculé'?2.5:2}" ${label==='Consigne'?'stroke-dasharray="5 4"':''}><title>${label}</title></path>`;}
 const f=simPreview===null?simEngine.frame:simEngine.history[simPreview];html+=`<path d="M${x(f.time)} ${T}V${H-B}" stroke="#c56800" stroke-width="1.5"/>`;
 $('#simChart').innerHTML=html;$('#simChartLegend').innerHTML=series.map(([a,color])=>`<span><i style="border-color:${color}"></i>${a}</span>`).join('');
}
function simEvent(now){try{if(simEngine.done)throw Error('Essai terminé : réinitialisez avant un nouvel événement.');const at=now?simEngine.time/60:Number($('#simEventAt').value);if(!now&&(!$('#simEventAt').checkValidity()||$('#simEventAt').value===''))throw Error('Minute invalide.');if(at>simEngine.config.duration)throw Error('Minute au-delà de la durée de cet essai.');const type=$('#simEvent').value;const global=['flexOn','flexOff','gridOff','gridOn','cloud','sun','limit','unlimit'].includes(type);simEngine.schedule({at,type,site:global?'all':$('#simEventSite').value});$('#simEventFeedback').textContent=`${TemporalModel.labels[type]} programmé à ${fmt(at)} min ; appliqué au prochain pas calculé.`;simScheduleList();}catch(e){$('#simEventFeedback').textContent='Événement refusé : '+e.message;}}
function simDownload(name,text,type){const u=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function simCompare(){
 $('#simComparison').hidden=savedRuns.length===0;if(!savedRuns.length)return;
 const a=savedRuns[0],b=savedRuns[1];let comparable=false;
 if(b){const ca={...a.config},cb={...b.config};delete ca.v2g;delete cb.v2g;const ev=r=>r.events.map(e=>({at:e.at,type:e.type,site:e.site}));comparable=JSON.stringify(ca)===JSON.stringify(cb)&&JSON.stringify(ev(a))===JSON.stringify(ev(b))&&a.timeSeconds===b.timeSeconds;}
 $('#simCompareNote').textContent=!b?'Essai A enregistré. Réinitialisez, modifiez un paramètre, puis mémorisez l’essai B.':comparable?'Conditions identiques hors activation V2G ; même temps calculé et mêmes événements.':'Conditions ou durées différentes : comparaison exploratoire, sans conclusion causale.';
 const rows=[['Recharge EV (kWh AC)','chargeKWh'],['Décharge EV (kWh AC)','dischargeKWh'],['Import réseau (kWh)','importKWh'],['Export réseau (kWh)','exportKWh'],['Pointe import (kW)','peakImport'],['Énergie site non servie (kWh)','unservedKWh'],['Critique non servie (kWh)','criticalUnservedKWh'],['Écart au service (kWh)','unmetKWh'],['Manque aux départs (kWh DC)','departureDeficitKWh'],['Commandes refusées','rejected']];
 $('#simCompareRows').innerHTML=rows.map(([label,key])=>`<tr><td>${label}</td><td>${fmt(a.metrics[key])}</td><td>${b?fmt(b.metrics[key]):'—'}</td><td>${b?fmt(b.metrics[key]-a.metrics[key]):'—'}</td></tr>`).join('');
}
$('#simPlay').addEventListener('click',simPlay);$('#simReset').addEventListener('click',simReset);
$('#simStep').addEventListener('click',()=>{simPause();simPreview=null;$('#simConfig').disabled=true;simEngine.advance(60);simRender();});
$('#simFinish').addEventListener('click',()=>{simPause();simPreview=null;$('#simConfig').disabled=true;simEngine.finish();simRender();});
$$('#simConfig input').forEach(e=>e.addEventListener('change',simReset));
$('#simPreset').addEventListener('change',()=>{if($('#simPreset').value==='backup'){$('#simDuration').value=360;$('#simBackup').checked=true;}simReset();});
$('#simInject').addEventListener('click',()=>simEvent(true));$('#simSchedule').addEventListener('click',()=>simEvent(false));
$('#simEvent').innerHTML=Object.entries(TemporalModel.labels).map(([key,label])=>`<option value="${key}">${esc(label)}</option>`).join('');
$$('[data-sim-layer]').forEach(b=>b.addEventListener('click',()=>{simLayer=b.dataset.simLayer;$$('[data-sim-layer]').forEach(x=>x.setAttribute('aria-pressed',x===b));simView();}));
$$('[data-chart]').forEach(b=>b.addEventListener('click',()=>{simChartMode=b.dataset.chart;$$('[data-chart]').forEach(x=>x.setAttribute('aria-pressed',x===b));simChart();}));
$('#simSeek').addEventListener('input',()=>{simPause();simPreview=Number($('#simSeek').value);simRender();});
$('#simChart').addEventListener('click',e=>{const rect=e.currentTarget.getBoundingClientRect(),x=(e.clientX-rect.left)/rect.width*920,t=Math.max(0,Math.min(1,(x-52)/(920-52-16)))*simEngine.config.duration*60;let best=0;simEngine.history.forEach((f,i)=>{if(Math.abs(f.time-t)<Math.abs(simEngine.history[best].time-t))best=i;});simPause();simPreview=best;simRender();});
$('#sceneSite').addEventListener('change',e=>{scene.site=e.target.value;$('#sceneX').value=scene.positions[scene.site][0];$('#sceneZ').value=scene.positions[scene.site][1];simView();});
$('#sceneLeft').addEventListener('click',()=>{scene.yaw-=.2;scene.render();});$('#sceneRight').addEventListener('click',()=>{scene.yaw+=.2;scene.render();});
$('#sceneTop').addEventListener('click',()=>{scene.pitch=1.49;scene.yaw=0;scene.render();});$('#sceneReset').addEventListener('click',()=>{scene.yaw=-.55;scene.pitch=.77;scene.zoom=1;$('#sceneZoom').value=1;scene.render();});
$('#sceneZoom').addEventListener('input',e=>{scene.zoom=Number(e.target.value);scene.render();});
for(const id of ['sceneX','sceneZ'])$('#'+id).addEventListener('input',()=>{scene.positions[scene.site]=[Number($('#sceneX').value),Number($('#sceneZ').value)];scene.render();});
$('#simEquipment').innerHTML=Object.entries(info).map(([key,v])=>`<option value="${key}">${esc(v[0])}</option>`).join('');$('#simEquipment').value='ems';$('#simEquipment').addEventListener('change',e=>simInspect(e.target.value));
$('#simSaveRun').addEventListener('click',()=>{savedRuns.push(JSON.parse(JSON.stringify(simEngine.report())));if(savedRuns.length>2)savedRuns.shift();simCompare();});
$('#simClearRuns').addEventListener('click',()=>{savedRuns=[];simCompare();});
$('#simJson').addEventListener('click',()=>simDownload('Dakar_V2G_Essai_R2.json',JSON.stringify({...simEngine.report(),plan3D:{positions:scene.positions,geographicValidation:false},comparison:savedRuns},null,2),'application/json'));
$('#simCsv').addEventListener('click',()=>{const header=['minutes','PCC_A_kW','PCC_B_kW','total_kW','EV_A_SoC_pct','EV_B_SoC_pct','BESS_A_SoC_pct','BESS_B_SoC_pct','import_cumule_kWh','export_cumule_kWh','recharge_EV_kWh','non_servi_kWh'];const lines=simEngine.history.map(f=>[f.time/60,f.sites[0].grid,f.sites[1].grid,f.total,f.sites[0].socAfter,f.sites[1].socAfter,f.sites[0].bessSoc,f.sites[1].bessSoc,f.metrics.importKWh,f.metrics.exportKWh,f.metrics.chargeKWh,f.metrics.unservedKWh].map(n=>n.toFixed(5).replace('.',',')).join(';'));simDownload('Dakar_V2G_Chroniques_R2.csv','\ufeff'+[header.join(';'),...lines].join('\r\n'),'text/csv;charset=utf-8');});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&simRunning){simPause();simRender();}});
matchMedia('(max-width:600px)').addEventListener('change',simView);
window.Simulator={get engine(){return simEngine;},get running(){return simRunning;},get scene(){return scene;},reset:simReset,pause:simPause,model:TemporalModel};
simReset();showTab('sim');
