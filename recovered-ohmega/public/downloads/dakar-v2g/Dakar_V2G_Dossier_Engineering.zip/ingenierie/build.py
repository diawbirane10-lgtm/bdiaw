from pathlib import Path
root=Path(__file__).resolve().parent
page=(root/'template.html').read_text()
page=page.replace('<title>Dakar V2G — architecture revue</title>','<title>Dakar V2G — simulateur temporel et plan 3D</title>')
page=page.replace('</style>',(root/'simulation.css').read_text()+'\n</style>')
page=page.replace('<nav class="nav" role="tablist" aria-label="Explorer le projet">','<nav class="nav" role="tablist" aria-label="Explorer le projet"><button id="tab-sim" role="tab" aria-selected="true" aria-controls="sim" tabindex="0"><span>01</span>Simulateur</button>')
page=page.replace('id="tab-system" role="tab" aria-selected="true"','id="tab-system" role="tab" aria-selected="false"').replace('aria-controls="system" tabindex="0"','aria-controls="system" tabindex="-1"')
page=page.replace('<span>01</span>Architecture','<span>02</span>Architecture').replace('<span>02</span>Revue critique','<span>03</span>Revue critique').replace('<span>03</span>Carte & données','<span>04</span>Carte & données').replace('<span>04</span>Essais & sources','<span>05</span>Essais & sources')
page=page.replace('<section id="system"', (root/'simulation.html').read_text()+'\n<section id="system"')
page=page.replace('<h1>La recharge intelligente,<br>avec ses limites réelles.</h1>','<h1>Tester le réseau.<br>Observer chaque décision.</h1>')
page=page.replace('CONCEPT RÉVISÉ · R1','SIMULATEUR · R2').replace('09 OCTOBRE 2026','10 OCTOBRE 2026').replace('architecture de concept R1','simulateur de concept R2')
page=page.replace('Prototype pédagogique · fonctionnement hors ligne','Simulation temporelle · fonctionnement hors ligne')
page=page.replace('Bilan AC, pas énergétique, réserve, limites de raccordement, absence de véhicule, îlotage et refus de commandes. Résultats reproductibles dans le dossier.','Bilan AC/DC, intégration par pas de 5 s, réserves, départs, limites et secours fini : 96 séquences, 311 042 contrôles et 11 essais complémentaires. Le modèle historique conserve 4 000 cas. Résultats et corrections dans le dossier.')
page=page.replace('Scénarios, onglets, clavier, import cartographique, impression et export. Débordements, erreurs de script et préférences de mouvement contrôlés.','Lecture/pause, événements, relecture, comparaison V1G/V2G, exports JSON/CSV et plan 3D manipulable. Dix tailles du simulateur, plus neuf tailles du concept historique. Aucun test physique ou fond OSM en ligne validé.')
page=page.replace('<script>__CONTENT__</script>','<script>__CONTENT__</script><script>__SIM_MODEL__</script>')
page=page.replace('<script>__APP__</script>','<script>__APP__</script><script>__SCENE__</script><script>__SIM_APP__</script>')
for key,file in [('MODEL','model.js'),('CONTENT','content.js'),('APP','app.js'),('SIM_MODEL','simulation-model.js'),('SCENE','scene3d.js'),('SIM_APP','simulation-app.js')]:
    page=page.replace('__'+key+'__',(root/file).read_text())
status=(root/'test-summary.txt').read_text() if (root/'test-summary.txt').exists() else 'NON TESTÉ\nNON TESTÉ'
model,ui=status.strip().split('\n')
page=page.replace('__MODEL_STATUS__',model).replace('__UI_STATUS__',ui)
target=root.parent/'Dakar_V2G_Architecture_Revisee.html'
target.write_text(page)
print(target)
