# Dakar V2G — cadrage de la revue R1

Date : 9 octobre 2026. Niveau documentaire : 1, fondations de concept. Porteur : utilisateur. Production et évaluation : rôles spécialisés exécutés successivement par l’assistant, complétés par des tests séparés du code applicatif. Aucune expertise professionnelle indépendante n’est revendiquée.

## Besoin et objectif

Explorer un réseau IIoT de recharge électrique dans l’agglomération de Dakar, avec recharge pilotée, bidirectionnalité éventuelle, coordination multisite, résilience et cybersécurité. Critiquer les idées initiales au regard des solutions existantes et du contexte local. Fournir une architecture recommandée et une page HTML interactive téléchargeable pour discussion avec un mentor.

Le résultat est une recommandation de concept, pas une installation dimensionnée. Dakar-centre, Pikine et Keur Massar sont des exemples. Aucun site n’est retenu sans données de demande, maîtrise foncière, raccordement et visite.

## Livrables

- DEL-001 : Dakar_V2G_Architecture_Revisee.html, autonome hors ligne pour la simulation et les textes.
- DEL-002 : dossier ZIP, revue, décisions, hypothèses, risques, sources, code et résultats des vérifications.

## Parties prenantes

Porteur du projet : choix du cas d’usage et collecte terrain. Exploitant de flotte/site : disponibilité, horaires, maintenance, foncier. Senelec : étude et conditions de raccordement, capacité locale et interface éventuelle. CRSE : qualification réglementaire et décisions applicables. Constructeurs véhicule/borne : compatibilité, sécurité et garantie. ARTP/opérateurs : données de couverture et QoS, complétées par mesures locales.

## Hypothèses

- HYP-001 : une flotte captive est un meilleur premier terrain qu’un réseau public non documenté. Inférence de conception à confirmer avec les usages.
- HYP-002 : accès réseau électrique possible ; la puissance admissible locale reste inconnue.
- HYP-003 : couples bidirectionnels disponibles pour un essai futur ; ni disponibilité locale ni garantie obtenues.
- HYP-004 : télémesure 5 s et validité 15 s sont des cibles initiales, jamais des garanties temps réel.
- HYP-005 : toutes les puissances, réserves et batteries de la simulation sont fictives.

## Interfaces et limites

INT-001 : véhicule–borne, ISO 15118-20 cible pour nouveau matériel qui le prend en charge ; vérifier le couple exact.
INT-002 : borne–CSMS, OCPP 2.1 cible bidirectionnelle ; prise en charge commerciale et interopérabilité à éprouver.
INT-003 : compteur/protections–EMS, interface locale selon matériel et étude.
INT-004 : coordination utility–agrégateur, à convenir avec Senelec ; aucune API, télémesure ni convention obtenue.
INT-005 : accès IP fixe/mobile, QoS à mesurer. Aucun maillage intégral direct entre les bornes distantes.

Les protections électriques sont matérielles et locales. L’EMS a une autorité bornée et une stratégie de repli. L’intégration fabricant doit garantir une seule chaîne d’arbitrage : éviter deux maîtres de commande concurrents. Aucun proxy OCPP artisanal ni protocole utility supplémentaire n’est imposé avant analyse des produits.

## Périmètre autorisé et actions futures

La demande autorise la revue, la construction, les tests et la remise de fichiers téléchargeables. Elle ne comporte ni achat, ni publication publique, ni contact avec les institutions, ni mise sous tension. Ces actions physiques ou externes nécessiteront une décision distincte. Aucun budget, tarif, revenu V2G ou certification n’est inventé.


## Extension R2 — 10 octobre 2026

Extension autorisée : essais temporels interactifs et visibilité des équipements en 3D. DEL-001/002 deviennent R2, sans publication. AC-S01..S08 régissent cette extension.

HYP-S01 profils déterministes fictifs et rendements constants ; HYP-S02 demande bâtiment délestée si insuffisance ; HYP-S03 secours critique 1 kW/site, sans recharge ; HYP-S04 positions de plan local métrique, aucune emprise géographique validée. Aucune portée de communication radio réelle ou garantie temps réel déduite de la simulation.
