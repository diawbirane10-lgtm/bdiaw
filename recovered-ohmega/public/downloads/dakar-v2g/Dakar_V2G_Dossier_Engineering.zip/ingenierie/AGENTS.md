# Instructions de travail SENSAT

Lire `PROJECT_BRIEF.md`, `ACCEPTANCE_CRITERIA.md`, `STATE.md`, `ISSUES.md` et `TASKS.md` avant toute modification substantielle.

Appliquer les règles suivantes :

- préserver les modifications existantes et les historiques ;
- identifier toute hypothèse, exigence, décision, test, risque, anomalie et preuve ;
- annoncer les fichiers ou sous-systèmes touchés avant une modification large ;
- ne jamais déclarer un succès sans résultat de test et preuve localisable ;
- distinguer absence de test, blocage et échec ;
- relancer les tests impactés après correction ;
- ne pas fermer sa propre anomalie sans vérification indépendante lorsque la criticité est majeure ou bloquante ;
- demander une validation humaine avant achat, publication, action externe, dérogation critique, suppression ou libération ;
- arrêter la boucle après trois échecs et produire une escalade factuelle.

Mettre à jour les registres dans l'ordre défini par le skill `sensat-quality-loop`.
