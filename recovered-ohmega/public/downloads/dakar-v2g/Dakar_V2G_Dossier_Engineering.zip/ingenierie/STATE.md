# État R1 — 9 octobre 2026

- Niveau déclaré/effectif : 1, fondations documentées. Les tests automatisés existent mais ne constituent pas une revendication de maturité SENSAT supérieure.
- Phase : concept recommandé et démonstrateur vérifié.
- Verdict périmètre numérique : PASS selon AC-001 à AC-010.
- Aptitude installation réelle : NON DÉMONTRÉE ; raccordement/export BLOQUÉ, autres essais NON TESTÉS.
- Baseline de discussion : R1. Aucune mise en service ni libération industrielle.

Terminé : recherche primaire, 13 critiques corrigées, décisions, page, modèle, navigateur, inventaire et dossier.

Restant : données de flotte/demande, étude de raccordement, position Senelec/CRSE, couple compatible garanti, protections/îlotage, QoS, cyber réel et économie.

## Historique

- 2026-10-09 : état initial CADRAGE, aucune preuve.
- 2026-10-09 : revue et corrections, tests modèle PASS puis test navigateur FAIL de formatage du test.
- 2026-10-09 : correction et reprises PASS ; examen visuel, corrections SVG/CSS et dernière reprise PASS.

Les rôles ont été exécutés successivement par le même assistant ; les tests sont des scripts séparés et les sources externes servent à la contradiction factuelle. Ce n’est pas une revue indépendante par plusieurs ingénieurs certifiés.


## Extension R2 — 10 octobre 2026

R2 remplace la baseline de discussion R1 pour le logiciel. Phase : simulateur temporel + plan de site 3D prêts pour étude et présentation. Niveau documentaire déclaré/effectif : 1. AC-S01..S08 PASS dans le périmètre pédagogique ; régressions R1 PASS. Aucun matériel ou système réel connecté ; aptitude terrain non démontrée.

Rôles séquentiels, tests distincts, corrections et limites traçables. Derniers résultats : 96 séquences, 311 042 contrôles, 11 essais complémentaires ; 10 tailles du simulateur / 40 couches-vues, plus régression sur 9 tailles du concept. Aucun test sur appareil mobile physique, aucune validation professionnelle indépendante.
