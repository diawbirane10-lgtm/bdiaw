# Plan de vérification

Concept : sources primaires, objections, décisions et inconnues explicites.
Modèle : conservation AC/énergie, réserves, plafonds, coupure, disponibilité et politique de refus sur 4 000 combinaisons et cas hostiles.
UI : navigateur réel, neuf vues, onglets/scénarios, clavier, import/export, mouvement réduit et CSS d’impression. Contrôle visuel des captures et reprises des tests impactés.

Terrain futur : revue électrique indépendante, mesures de flotte/PCC/WAN, banc véhicule–borne, garantie, avis réseau/régulateur, procédure de sécurité, essais de coupure et restauration, audit cyber puis pilote instrumenté. Aucun de ces essais réels n’est exécuté par le démonstrateur.


## Extension R2 — 10 octobre 2026

Méthode ajoutée : intégration 5 s, vérifications de conservation indépendantes, longues séquences et effets fonctionnels V2G. Référence analytique secours et charge, déterminisme et absence d'énergie inventée. Navigateur : interactions réelles, résultat identique quelle que soit vitesse, commandes et programmes, exports analysés, inspection 3D et 40 vues. Résultats TST-S01/S02 dans TEST_REPORT.md.
