/* Projection perspective de volumes métriques en SVG, sans dépendance ou données 3D externes. */
'use strict';
class SiteScene{
 constructor(svg,onInspect){this.svg=svg;this.onInspect=onInspect;this.yaw=-.55;this.pitch=.77;this.zoom=1;this.positions={A:[0,-1.5],B:[0,-1.5]};this.site='A';this.frame=null;this.suppress=false;this.bind();}
 project([x,y,z]){const X=x*Math.cos(this.yaw)-z*Math.sin(this.yaw),Z=x*Math.sin(this.yaw)+z*Math.cos(this.yaw);const Y=y*Math.cos(this.pitch)-Z*Math.sin(this.pitch),depth=y*Math.sin(this.pitch)+Z*Math.cos(this.pitch);const k=16*this.zoom*100/(100-depth);return [450+X*k,262-Y*k,depth];}
 points(v){return v.map(p=>this.project(p).slice(0,2).map(n=>n.toFixed(2)).join(',')).join(' ');}
 box(id,x,z,w,d,h,y=0,color='#a3b5ae',key=null){
  const p=[[x-w/2,y,z-d/2],[x+w/2,y,z-d/2],[x+w/2,y,z+d/2],[x-w/2,y,z+d/2],[x-w/2,y+h,z-d/2],[x+w/2,y+h,z-d/2],[x+w/2,y+h,z+d/2],[x-w/2,y+h,z+d/2]];
  const faces=[[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7]];
  const tinted=[.78,.65,.82,.72,1];
  const tint=f=>{let a=color.slice(1).match(/../g).map(v=>Math.round(parseInt(v,16)*f).toString(16).padStart(2,'0'));return '#'+a.join('');};
  const polygons=faces.map((v,i)=>({depth:v.reduce((n,k)=>n+this.project(p[k])[2],0)/v.length,html:`<polygon points="${this.points(v.map(k=>p[k]))}" fill="${tint(tinted[i])}" stroke="#466459" stroke-width="0.55"/>`})).sort((a,b)=>a.depth-b.depth).map(f=>f.html).join('');
  return {depth:this.project([x,y+h/2,z])[2],html:`<g ${key?`class="sceneobject" data-object="${key}" role="button" tabindex="0" aria-label="${esc(id)}"`:''}>${polygons}</g>`};
 }
 render(frame){
  if(frame)this.frame=frame;if(!this.frame)return;const f=this.frame,s=f.sites.find(s=>s.id===this.site);const objects=[];
  let bg=`<rect width="900" height="470" fill="#f1f6f2"/><polygon points="${this.points([[-14,0,-10],[14,0,-10],[14,0,11],[-14,0,11]])}" fill="#dde9df" stroke="#9fb6aa" stroke-width="1"/>`;
  for(let x=-12;x<=12;x+=2)bg+=`<path d="M${this.project([x,.015,-10]).slice(0,2).join(' ')}L${this.project([x,.015,11]).slice(0,2).join(' ')}" stroke="#c5d5c8" stroke-width=".6"/>`;
  for(let z=-10;z<=10;z+=2)bg+=`<path d="M${this.project([-14,.015,z]).slice(0,2).join(' ')}L${this.project([14,.015,z]).slice(0,2).join(' ')}" stroke="#c5d5c8" stroke-width=".6"/>`;
  objects.push(this.box('Accès au stationnement',0,8,28,4,.035,0,'#62716f'));
  for(const x of [0,4,8]){bg+=`<polygon points="${this.points([[x-1.4,.04,-.5],[x+1.4,.04,-.5],[x+1.4,.04,5],[x-1.4,.04,5]])}" fill="#f7faf6" stroke="#829b8d" stroke-width="1" stroke-dasharray="${x?'5 4':'0'}"/>`;}
  objects.push(this.box('Local électrique et contrôleur',-7,-3,5,4,3.5,0,'#b7c6bd','ems'));
  objects.push(this.box('Compteur et protections au raccordement',-4.25,-3.5,.7,.55,1.8,0,f.island?'#ac494f':'#d6a24a','pcc'));
  if(f.options.pv){for(let x=-8.7;x<-5;x+=1.2)objects.push(this.box('Panneaux photovoltaïques',x,-3,1.08,3.3,.09,3.55,'#34606a','pv'));}
  if(f.options.backup)objects.push(this.box('Batterie fixe du secours',-7,1,1.7,1.1,2.1,0,s.bess>.001?'#167f76':'#819e8e','bess'));
  const [cx,cz]=this.positions[this.site],state=!s.available||f.island?'#86918b':s.ev<-.001?'#00796e':s.ev>.001?'#bd7b19':'#718b80';
  objects.push(this.box('Borne de recharge '+this.site,cx,cz,.8,.55,2.05,0,state,'charger'));
  objects.push(this.box('Écran de la borne',cx,cz+.3,.45,.035,.4,1.28,'#17373d','charger'));
  if(s.available){objects.push(this.box('Véhicule électrique '+this.site,0,2.2,1.8,4.1,.65,.25,'#c3d4cc','ev'));objects.push(this.box('Habitacle du véhicule',0,2.3,1.5,2.0,.52,.9,'#497779','ev'));for(const x of [-.85,.85])for(const z of [.9,3.5])objects.push(this.box('Roues',x,z,.24,.6,.5,.08,'#2e403e'));}
  const cable=[[-4.25,.04,-3.5],[cx,.04,-3.5],[cx,.04,cz]];
  bg+=`<polyline points="${this.points(cable)}" fill="none" stroke="${state}" stroke-width="3" stroke-dasharray="5 3"/>`;
  objects.sort((a,b)=>a.depth-b.depth);this.svg.innerHTML=bg+objects.map(o=>o.html).join('');
  const tag=(p,title,sub)=>{const q=this.project(p);return `<text class="scenetag" x="${q[0]}" y="${q[1]}" text-anchor="middle">${esc(title)}<tspan class="scenesub" x="${q[0]}" dy="18">${esc(sub)}</tspan></text>`;};
  this.svg.insertAdjacentHTML('beforeend',tag([cx,2.9,cz],'Borne '+s.id,`${s.mode} · ${fmt(s.ev)} kW`)+tag([-7,4.4,-3],'Local électrique','EMS · PCC')+tag([8,.6,3],'Extension','Emplacements réservés')+`<text x="20" y="26" font-size="14" font-weight="650">SITE ${s.id} · plan illustratif, unités en mètres</text><text x="20" y="450" font-size="12">Véhicule : ${s.available?fmt(s.socAfter)+' %':'absent'} · PCC : ${fmt(s.grid)} kW · WAN : ${s.wan?'disponible':'perdu'}</text>`);
  for(const g of this.svg.querySelectorAll('[data-object]')){g.addEventListener('click',()=>{if(!this.suppress)this.onInspect(g.dataset.object);});g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();this.onInspect(g.dataset.object);}});}
  const distance=Math.hypot(cx+4.25,cz+3.5);$('#sceneDistance').textContent=`Borne ${s.id} : X = ${fmt(cx)} m, Y = ${fmt(cz)} m. Distance droite depuis le PCC ≈ ${fmt(distance)} m (tracé de plan).`;
 }
 bind(){
  let down=null;this.svg.addEventListener('pointerdown',e=>{if(e.button!==0)return;down={x:e.clientX,y:e.clientY,yaw:this.yaw,pitch:this.pitch,key:e.target.closest('[data-object]')?.dataset.object};this.svg.setPointerCapture(e.pointerId);});
  this.svg.addEventListener('pointermove',e=>{if(!down)return;const dx=e.clientX-down.x,dy=e.clientY-down.y;if(Math.hypot(dx,dy)>4){this.suppress=true;this.yaw=down.yaw+dx*.008;this.pitch=Math.max(.2,Math.min(1.5,down.pitch+dy*.005));this.render();}});
  const up=()=>{if(down?.key&&!this.suppress)this.onInspect(down.key);down=null;setTimeout(()=>{this.suppress=false;},150);};this.svg.addEventListener('pointerup',up);this.svg.addEventListener('pointercancel',()=>{down=null;this.suppress=false;});
  this.svg.addEventListener('keydown',e=>{if(e.target!==this.svg)return;let hit=true;if(e.key==='ArrowLeft')this.yaw-=.12;else if(e.key==='ArrowRight')this.yaw+=.12;else if(e.key==='ArrowUp')this.pitch=Math.min(1.5,this.pitch+.1);else if(e.key==='ArrowDown')this.pitch=Math.max(.2,this.pitch-.1);else if(e.key==='+'||e.key==='=')this.zoom=Math.min(1.6,this.zoom+.1);else if(e.key==='-')this.zoom=Math.max(.6,this.zoom-.1);else hit=false;if(hit){e.preventDefault();$('#sceneZoom').value=this.zoom;this.render();}});
 }
}
