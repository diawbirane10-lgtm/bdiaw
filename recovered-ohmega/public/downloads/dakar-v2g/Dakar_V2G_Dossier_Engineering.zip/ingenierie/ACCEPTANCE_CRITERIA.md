# Critères de réception du démonstrateur R1

Les statuts portent uniquement sur la revue et le démonstrateur. PASS ne qualifie jamais l’équipement réel. Tolérance des invariants numériques : 1e-8 kW ou kWh selon l’équation.

| ID | Exigence / critère | Vérification | Preuve | Statut |
| --- | --- | --- | --- | --- |
| AC-001 / REQ-001 | Sources primaires et limites de disponibilité explicites | Inspection des sources et de l’inventaire | EV-001 / SOURCES.md, DATA_INVENTORY.csv | PASS, repérage uniquement pour les pages non récupérées |
| AC-002 / REQ-002 | Revue énergie, contrôle, telecom, cyber, économie, réglementation, SIG et exploitation | 13 objections et corrections traçables | EV-002 / FINAL_REPORT.md | PASS pour la revue de concept |
| AC-003 / REQ-003 | Conservation AC et énergie ; plafonds locaux, réserve et absence respectés | 4 000 cas paramétrés et références | EV-003 / evidence/model-results.json | PASS pour le modèle |
| AC-004 / REQ-004 | Aucun échange réseau en coupure ; pas de recharge dans cette variante | Test conservation et îlotage | EV-003 | PASS pour le modèle |
| AC-005 / REQ-005 | Rejet identité, permission, expiration, rejeu, mesure périmée, coupure et consigne excessive | 10 cas hostiles et rejeu après acceptation | EV-003 | PASS pour la fonction pédagogique |
| AC-006 / REQ-006 | Tous les scénarios et onglets visibles sans débordement global entre 320 et 1440 px | Chromium réel, 9 viewports, 90 scénarios/vues et 36 onglets/vues | EV-004 / evidence/browser-results.json | PASS |
| AC-007 / REQ-007 | Import local GeoJSON valide ; erreur n’efface pas la couche ; propriétés non exécutées | Tests import valide/invalide et propriété hostile | EV-004 | PASS |
| AC-008 / REQ-008 | Export JSON, clavier, équipement sélectionnable et mouvement réduit | Vérifications navigateur | EV-004 | PASS |
| AC-009 / REQ-009 | Aucune requête externe pour l’usage hors ligne | Surveillance réseau du navigateur, fond OSM non chargé | EV-004 | PASS |
| AC-010 / REQ-010 | Reproductibilité et limites de terrain conservées | Code, paramètres, versions, baseline | EV-005 / CONFIGURATION_BASELINE.md | PASS documentaire |

## Conditions du système réel

REQ-R01 raccordement/export : BLOQUÉ, étude et convention non obtenues.
REQ-R02 couple bidirectionnel : NON TESTÉ, aucun matériel essayé.
REQ-R03 îlotage électrique : NON TESTÉ, aucun transfert physique.
REQ-R04 cybersécurité industrielle : NON TESTÉ, aucune PKI ou protection réseau industrielle.
REQ-R05 implantation/TCO : NON TESTÉ, aucune demande ou consommation locale mesurée.

Verdict : démonstrateur reçu dans son périmètre pédagogique ; aptitude au déploiement non démontrée.

## Extension R2 — simulation temporelle (critères avant réalisation)

- AC-S01 : intégration kW→kWh à chaque pas, conservation AC et énergie batterie, sans SoC négatif/au-delà de 100 % ; vérification indépendante par équations et cas limites.
- AC-S02 : exécution déterministe à paramètres/événements identiques ; vitesse de lecture indépendante du temps physique ; pause et remise à zéro testées.
- AC-S03 : défaut réseau coupe les échanges au PCC ; repli local en perte WAN ; réserve empêche décharge ; véhicule absent ne charge/décharge plus.
- AC-S04 : limite d'import/export, insuffisance déclarée, pertes et énergie non servie comptabilisées ; tests de séquences longues.
- AC-S05 : injonctions cyber refusées avec effet mesurable nul sur les consignes ; horloge/validité/anti-rejeu du modèle, sans prétendre implémenter TLS.
- AC-S06 : graphiques, états SVG, SoC, journaux et bilan suivent le même état simulé ; clavier/mobile/export/comparaison vérifiés dans Chromium.
- AC-S07 : comparaison V1G/V2G à conditions identiques, exports JSON et CSV, aucun secret ni objet physique connecté.

Statut initial de ces critères : NON TESTÉ. Limites : simulateur énergétique quasi-statique ; aucune étude de stabilité, tension, fréquence ou conformité industrielle.

Ajout avant vérification de la vue 3D : AC-S08 — volumes perspectifs manipulables, rotation/zoom/clavier, sélection des équipements, deux sites et position de borne modifiable sans altérer le modèle électrique. Implantation illustrative explicitement distinguée du SIG réel. Statut initial : NON TESTÉ.


## Extension R2 — 10 octobre 2026

Clôture R2 : AC-S01..S08 PASS selon REQUIREMENTS_TRACEABILITY.md et EV-S01..S04. Les critères terrain R1 restent BLOQUÉS / NON TESTÉS. Le statut initial avant réalisation est conservé ci-dessus.
