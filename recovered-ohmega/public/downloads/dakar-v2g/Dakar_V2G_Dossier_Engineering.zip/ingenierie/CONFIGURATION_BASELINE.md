# Baseline de discussion R1

Date : 2026-10-09. Niveau documentaire 1. Fichier HTML autonome construit depuis template.html, model.js, content.js, app.js et build.py. La version antérieure n’est pas écrasée.

Environnement vérifié : Node.js 24.19.0, Python 3, Playwright 1.62.1, Chromium 153.0.8010.0 (@sparticuz/chromium 153.0.0). Simulation et page sans dépendance runtime externe. Les dépendances de test ne sont pas nécessaires à l’utilisateur de la page.

Paramètres : tableau specs et options dans model.js ; données fictives ; aucune télémesure réelle. Sources : SOURCES.md, extraction/consultation du 9 octobre 2026, pages ARTP non récupérées signalées.

Empreintes des fichiers distribués : MANIFEST.sha256 au niveau supérieur du ZIP. Les sources suffisent à reconstruire l’HTML ; test-summary.txt contient uniquement le résumé des derniers tests exécutés.

Baseline documentaire de concept ; pas de libération industrielle, audit independent professionnel ou certification.


## Extension R2 — 10 octobre 2026

Baseline R2 du 2026-10-10 : fichiers originaux + simulation-model.js, simulation-app.js, simulation.html, simulation.css et scene3d.js. build.py assemble un HTML autonome, sans dépendance externe pour simulation/3D. Le ZIP contient tous les fichiers de construction et tests, README R2 et manifeste SHA-256. Sources consultées le 9 octobre non réactualisées ni transformées en mesures de terrain.

Environnement : Node 24.19.0, Python 3, Chromium 153.0.8010.0, Playwright 1.62.1. Binaire empaqueté uniquement pour essais de cette session, non distribué. Tolérance tests temporels 1e-7, pas 5 s. Batteries EV 60 kWh/site, rendement 0,94 par sens ; BESS 12 kWh/site, SoC 70 %/plancher 40 %/rendement 0,90, secours ≤1 kW ; aucun modèle de vieillissement ou recharge du BESS.

Cible téléchargée : ouvrir le HTML dans un navigateur moderne. Tests uniquement Chromium. R1 conservée dans les historiques, versions antérieures des livrables préservées lors de la mise à jour.
