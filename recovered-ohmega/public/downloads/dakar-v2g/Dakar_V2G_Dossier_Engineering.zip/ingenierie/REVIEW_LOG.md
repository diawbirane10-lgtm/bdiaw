# Journal de la boucle d’ingénierie

RVW-001 à RVW-013 : objections détaillées dans FINAL_REPORT.md et la page.

Cycle 1 : état de l’art et contexte ; correction énergie/résilience/communication/SIG/régulation.
Cycle 2 : production du modèle et vérification séparée des invariants ; PASS. Renforcement du garde : horloge locale, anti-rejeu et durée bornée ; nouvelle vérification PASS.
Cycle 3 : navigateur réel ; erreur d’attente de formatage corrigée puis PASS. Inspection des images ; liaison/label/mouvement réduit corrigés ; reprise complète PASS.

Pas de succession artificielle de consensus : les inconnues physiques ne sont pas fermées. Les rôles sont séquentiels ; une véritable revue indépendante terrain est nécessaire avant déploiement.


## Extension R2 — 10 octobre 2026

Automatique : remplacement des snapshots par intégration, énergie finie, réserves, besoins aux départs ; tests détectent une décharge impossible malgré option V2G et entraînent correction.
Énergie : bilan AC/DC et rendement testés, déficits déclarés, aucun secours perpétuel.
UI/SIG : plan3D local manipulable séparé de la carte, absence de géoréférencement affichée ; responsive et clavier vérifiés.
Évaluation : moteur vs équations et navigateur vs résultats, reprises après corrections et régression R1. Rôles exécutés séquentiellement ; aucune certification multi-ingénieurs.
