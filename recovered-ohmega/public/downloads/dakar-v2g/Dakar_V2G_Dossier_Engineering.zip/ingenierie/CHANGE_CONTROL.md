# Historique des changements

- CHG-001 / 2026-10-09 : modèles SENSAT initialisés au niveau 1 ; empreintes initiales conservées dans config/initial-template-hashes.json.
- CHG-002 / 2026-10-09 : revue de l’idée initiale ; retrait du doublement général, de l’autonomie totale présumée, de la promesse de secours V2G et de la compensation arbitraire inter-sites.
- CHG-003 / 2026-10-09 : demande supplémentaire de cartographie et de données ARTP/Senelec/CRSE intégrée au périmètre explicitement par l’utilisateur.
- CHG-004 / 2026-10-09 : création du démonstrateur, modèle AC, sources, inventaire et import GeoJSON local.
- CHG-005 / 2026-10-09 : corrections graphiques/UI/tests et renforcement de validité/rejeu de la politique pédagogique ; reprises TST-001/TST-002 PASS.

Le fichier de concept antérieur n’est pas remplacé. Aucune publication publique, connexion industrielle, achat ou contact tiers effectué.


## Extension R2 — 10 octobre 2026

CHG-S01, autorisée par demande utilisateur : remplacer les scénarios seuls par une simulation temporelle et ajouter un plan de bornes 3D. Affecte nouveaux modules simulation-model.js / simulation-app.js / simulation.css / simulation.html / scene3d.js, réutilisation contrôlée du renderer app.js, assemblage build.py. Sources et données terrain non modifiées.

Essais ajoutés TST-S01/S02 ; régression TST-001/002 PASS. Livrables DEL-001/002 mis à jour en R2, mêmes identités et historiques. Aucune publication, installation ou action sur le réseau.
