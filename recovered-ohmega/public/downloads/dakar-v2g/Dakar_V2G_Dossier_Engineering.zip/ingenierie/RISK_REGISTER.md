# Risques de la future installation

| ID | Risque | Traitement recommandé | Preuve / état |
| --- | --- | --- | --- |
| RSK-001 | Dépassement du départ ou tension/harmoniques hors limites | Étude locale, compteur PCC, limites EMS et protections matérielles | REQ-R01, BLOQUÉ |
| RSK-002 | Réalimentation involontaire d’un réseau en coupure | Isolement et anti-îlotage ; secours distinct, formation réseau et reconnexion étudiées | REQ-R03, NON TESTÉ |
| RSK-003 | Indisponibilité des véhicules ou réserve insuffisante | Consentement, heure de départ, enveloppe avec durée, retrait immédiat si absent | TST-001 seulement pédagogique |
| RSK-004 | Identité compromise, rejeu, commande excessive | mTLS/PKI, moindre privilège, durée, journal, arbitrage local et incident response | TST-001 seulement politique |
| RSK-005 | Perte WAN ou service central | Repli EMS, données expirantes, UPS contrôle ; second accès justifié par QoS/cause commune | TST-001/002 concept |
| RSK-006 | Revenus surestimés et batterie dégradée | V1G de référence, TCO, garantie, pertes et cycle de batterie ; aucun revenu V2G présumé | REQ-R05, NON TESTÉ |
| RSK-007 | Choix de site à partir de données GIS incomplètes | Source/date/licence, filtre foncier/demande et visite ; étude Senelec obligatoire | Inventaire, pas de candidat validé |
| RSK-008 | Chaleur, poussière, salinité, eau, incendie, vandalisme | Inspection, spécifications fabricant, drainage, déclassement, maintenance et secours | REQ-R05, NON TESTÉ |
| RSK-009 | Fuite de données personnelles ou réseaux sensibles | Minimisation, pseudonymes, accès par rôle, durée de conservation, couches sensibles privées | Non implémenté en industriel |
| RSK-010 | Dépendance au fond cartographique externe | HTML offline pour le concept ; couche datée locale, tuiles maîtrisées pour production | EV-004 : aucune requête externe par défaut |

Les niveaux de fréquence et les coûts ne sont pas quantifiés sans données. Aucun risque physique élevé n’est accepté par ce dossier ; aucun déploiement n’est approuvé.


## Extension R2 — 10 octobre 2026

RSK-S01 : confondre une scène 3D avec une implantation validée. Réduction : unités de plan et caractère illustratif, absence de hauteur/empreinte réelle, cartographie séparée. Porteur : validation SIG/terrain ultérieure.

RSK-S02 : conclure que V2G réduit forcément l'énergie ou crée un revenu. Réduction : bilan import/export/charge/décharge/pertes et comparaison à événements identiques ; aucune tarification ni vieillissement simulé.

RSK-S03 : confondre temps simulé et temps réel de commande industrielle. Réduction : accélération explicitée, protections logiques seulement, absence de tension/fréquence/latence mesurée. Chaque limite physique reste à valider.
