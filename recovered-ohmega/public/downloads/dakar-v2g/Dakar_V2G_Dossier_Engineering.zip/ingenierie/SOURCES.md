# Sources primaires et statut d’acquisition

Consultation : 9 octobre 2026. Les affirmations restent limitées au contenu effectivement récupéré ou au repérage explicite.

## S01 — The Mobility House · contrôle local

https://www.mobilityhouse.com/int_en/our-company/newsroom/article/chargepilot-standalone-product

Date : 5 mai 2026.

Le contrôle local indépendant du cloud est déjà une fonction industrielle.

## S02 — Nuvve · agrégation et compatibilité

https://nuvve.com/faq/which-vehicles-are-compatible-with-nuvves-v2g/

Date : Consulté le 9 oct. 2026.

Le constructeur doit permettre la charge/décharge ; un couple véhicule–borne adapté est requis.

## S03 — CFAO / BYD · contexte sénégalais

https://www.cfaogroup.com/wp-content/uploads/2024/07/cp-cfao_byd_senegal_fr-vdef.pdf

Date : 11 juillet 2024.

Annonce de véhicules et de projets de recharge à Dakar. Ne prouve ni disponibilité actuelle, ni compatibilité V2G.

## S04 — Senelec · guichet unique

https://www.senelec.sn/informations/guichet-unique/

Date : Consulté le 9 oct. 2026.

Procédure de dossier technique et de raccordement ; une carte publique ne remplace pas cette étude.

## S05 — Senelec · chiffres clés

https://www.senelec.sn/qui-sommes-nous/chiffres-cles/

Date : Séries affichées 2022–2025.

Statistiques nationales d’énergie et de puissance. Granularité insuffisante pour un départ local.

## S06 — Senelec · rapports annuels

https://www.senelec.sn/rapports/

Date : Rapport 2024 repéré.

Contexte système et exploitation ; pas de profil de charge ouvert pour chaque site candidat identifié.

## S07 — CRSE · rapport 2024

https://www.crse.sn/crse_document/rapport-annuel-dactivites-crse-exercice-2024/

Date : Exercice 2024.

Publication de régulation, tarifs et performances sectorielles. Texte PDF complet non analysé ici.

## S08 — CRSE · tarifs Senelec 2026

https://www.crse.sn/crse_document/decision-n2025-140-relative-a-lapprobation-de-la-grille-tarifaire-de-senelec-applicable-a-compter-du-1er-janvier-2026/

Date : Application à partir du 1 janv. 2026.

Décision tarifaire repérée ; extraction des tarifs et du régime applicable au pilote à réaliser. Aucun prix inventé.

## S09 — CRSE · autoproduction

https://www.crse.sn/crse_document/decret-no-2025-1757-modifiant-le-decret-n-2023-286-du-07-fevrier-2023-relatif-a-lactivite-dautoproduction-denergie-electrique/

Date : Décret 2025-1757.

Modification du cadre antérieur repérée. L’assimilation juridique du V2G à l’autoproduction n’est pas tranchée ici.

## S10 — ARTP · SUNU Carto

https://artp.sn/espace-multimedia/sunu-carto-visualiser-la-couverture-reseau-sur-lensemble-du-territoire

Date : Consulté le 9 oct. 2026.

Carte de couverture annoncée par l’ARTP. Index public repéré ; récupération de la page en erreur 502, aucune couche vectorielle extraite.

## S11 — ARTP · couverture et QoS

https://artp.sn/observatoire/qualite-de-service/mesure-de-la-couverture-et-de-la-qos

Date : Consulté le 9 oct. 2026.

Campagnes de mesures repérées dans l’index public. Résultats bruts et API cartographique non récupérés.

## S12 — OCA · OCPP 2.1

https://openchargealliance.org/ocpp-2-1-is-now-available/

Date : 23 janvier 2025.

Support de fonctions bidirectionnelles et ISO 15118-20. Le support produit doit être vérifié séparément.

## S13 — OCA · exploitation sécurisée

https://openchargealliance.org/ocpp-info-whitepapers/security-operations-guide/

Date : Version 2, sept. 2026.

Gestion opérationnelle de la sécurité, à appliquer au système réel.

## S14 — NIST · sécurité OT

https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-82r3.pdf

Date : SP 800-82r3, 2023.

Référence pour segmentation, accès, supervision et continuité des systèmes industriels.

## S15 — DOE · recharge bidirectionnelle

https://www.energy.gov/cmei/femp/bidirectional-charging-and-electric-vehicles-mobile-storage

Date : Consulté le 9 oct. 2026.

Distinguer services réseau et alimentation locale, avec équipement et interconnexion adaptés.

## S16 — QGIS · code source

https://github.com/qgis/QGIS

Date : Consulté le 9 oct. 2026.

SIG libre pour analyse spatiale et croisement des couches ; recommandé pour la présélection.

## S17 — Overture · données mondiales

https://docs.overturemaps.org/getting-data/cloud-sources/

Date : Consulté le 9 oct. 2026.

GeoParquet et thèmes géographiques. Les tuiles d’exploration ne sont pas garanties pour un service de production.

## S18 — Kepler.gl · visualisation

https://github.com/keplergl/kepler.gl

Date : Consulté le 9 oct. 2026.

Exploration de grands jeux de données géographiques. Ne crée pas les données manquantes.

## S19 — MapLibre GL JS · affichage web

https://github.com/maplibre/maplibre-gl-js

Date : Consulté le 9 oct. 2026.

Moteur cartographique libre ; fond de carte, hébergement des tuiles et licences restent à choisir.

## S20 — Geofabrik · Sénégal / Gambie

https://download.geofabrik.de/africa/senegal-and-gambia.html

Date : Extrait daté du 8 oct. 2026 repéré.

Données OSM en PBF, Shapefile et GeoPackage. Attribution OSM et obligations ODbL à respecter.
