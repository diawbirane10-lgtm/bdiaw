# Index des preuves R1

| ID | Objet | Emplacement | Domaine |
| --- | --- | --- | --- |
| EV-001 | Sources vérifiées et inventaire | SOURCES.md / DATA_INVENTORY.csv | Recherche primaire ; limitations documentées |
| EV-002 | Objections et décisions | FINAL_REPORT.md / DECISIONS.md | Revue de concept, rôles séquentiels |
| EV-003 | Résultats du modèle | evidence/model-results.json / tests/model.cjs | Modèle numérique pédagogique |
| EV-004 | Résultats navigateur | evidence/browser-results.json / tests/browser.mjs | UI locale, pas de disponibilité OSM externe |
| EV-004A | Capture grand écran | evidence/desktop.png | Inspection visuelle |
| EV-004B | Capture mobile 390 px | evidence/mobile.png | Inspection visuelle |
| EV-005 | Empreintes et versions | CONFIGURATION_BASELINE.md / MANIFEST.sha256 | Baseline documentaire de concept |
| EV-006 | Export de scénario | evidence/exported-case.json | Bilan exporté −2 kW, cas fictif |

Aucune mesure électrique, donnée de feeder Senelec, convention d’injection ou donnée personnelle collectée.


## Extension R2 — 10 octobre 2026

| ID | Objet | Emplacement |
| --- | --- | --- |
| EV-S01 | 96 séquences et 11 références / effets fonctionnels | tests/temporal.cjs ; evidence/temporal-results.json |
| EV-S02 | Essais UI, 3D et 40 contrôles responsives | tests/simulation-browser.mjs ; evidence/simulation-browser-results.json |
| EV-S03 | Captures R2 examinées | evidence/simulator-desktop.png ; simulator-outage.png ; simulator-mobile.png |
| EV-S04 | Exports réellement téléchargés et analysés | evidence/temporal-export.json ; temporal-export.csv |

Les anciennes preuves EV-003/004 ont été régénérées par régression sur R2 ; leurs historiques restent dans TEST_REPORT.md.


EV-S05 : MANIFEST.sha256 et package_dossier.py — contrôle d’intégrité et reconstruction distribuée à l’identique (TST-S03 PASS).
