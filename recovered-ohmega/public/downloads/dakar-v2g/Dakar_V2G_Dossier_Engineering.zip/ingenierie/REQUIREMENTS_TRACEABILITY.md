# Traçabilité R1

REQ-001 à REQ-010 sont reliées aux AC de même numéro dans ACCEPTANCE_CRITERIA.md, et aux EV-001 à EV-005. Toutes les exigences de réception du démonstrateur disposent d’une méthode et d’une preuve localisable.

| Exigence réelle | Méthode future | Preuve absente | Statut |
| --- | --- | --- | --- |
| REQ-R01 : raccordement/export autorisé et sûr | Étude Senelec, avis réglementaire, essais et convention | Puissance locale, paramètres de départ, conditions d’export | BLOQUÉ |
| REQ-R02 : charge/décharge compatible | Banc véhicule–borne, interopérabilité, constructeur | Essais et garantie | NON TESTÉ |
| REQ-R03 : continuité locale en coupure | Étude protections, essai isolement/transfert/resynchronisation | Matériel et résultats | NON TESTÉ |
| REQ-R04 : cyber industriel | PKI, segmentation, tests d’intrusion, révocation et restauration | Audit technique réel | NON TESTÉ |
| REQ-R05 : implantation viable | SIG + terrain + flotte + coût + profils mesurés | Demande et TCO | NON TESTÉ |

Une source normative ou commerciale explique une possibilité ; elle ne remplace pas les preuves de notre installation.


## Extension R2 — 10 octobre 2026

| Critère | Vérification / preuve | Résultat |
| --- | --- | --- |
| AC-S01 / S04 | TST-S01 / EV-S01 : bilans, références, limites et déficits | PASS numérique |
| AC-S02 | TST-S01 déterminisme ; TST-S02 lecture/pause/reset/vitesse | PASS |
| AC-S03 | TST-S01 coupure/WAN/réserve/départ ; TST-S02 état UI | PASS numérique |
| AC-S05 | TST-S01 attaque et énergie inchangée ; TST-S02 journal | PASS règles pédagogiques |
| AC-S06 | TST-S02 / EV-S02/S03 : courbes, couches, UI, tailles et exports | PASS Chromium |
| AC-S07 | Référence V1G/V2G ; comparaison et downloads EV-S04 | PASS |
| AC-S08 | Manipulations 3D, sélection, sites et déplacement sans effet électrique | PASS plan illustratif |

REQ-R01..R05 : statuts terrain inchangés, BLOQUÉ / NON TESTÉ.
