'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>new Intl.NumberFormat('fr-FR',{maximumFractionDigits:1}).format(Math.abs(n)<.001?0:n);
let layer='energy',selected='ems',result, imported=null;
const info={
 grid:['Réseau Senelec / interface à convenir','Source principale proposée. Chaque raccordement doit être étudié. Une interface numérique de demande de flexibilité, ses données disponibles et ses règles de paiement ne sont pas confirmées. La CRSE encadre le secteur ; elle n’est pas le contrôleur temps réel des bornes.'],
 pcc:['Raccordement, protections et compteur','Le compteur bidirectionnel mesure l’import et l’export au PCC. Les protections, la terre, l’isolement et les limites du raccordement sont propres au site. En coupure, aucun véhicule ne doit réalimenter un réseau public non isolé. Les protections matérielles ne reposent pas sur le cloud.'],
 pv:['Solaire — option énergétique','Convertisseur PV raccordé au bus AC, dimensionné après mesure du profil et du site. La disponibilité solaire varie. Dans notre variante de coupure, le PV est arrêté par hypothèse conservatrice ; une exploitation en îlot demande une conception spécifique.'],
 bess:['Batterie fixe — variante de continuité','Elle est facultative. Un système grid-forming et un isolement adapté peuvent maintenir un îlot local étudié. La simulation utilise 12 kWh, SoC 70 %, réserve 40 %, rendement 90 % et 1 kW critique : 3,24 h théoriques. Ce n’est ni un dimensionnement, ni une autonomie garantie.'],
 load:['Bâtiment et services du site','Charges du bâtiment incluses dans le bilan PCC : 12 kW au site A et 8 kW au B, valeurs fictives. En variante de secours, seulement 1 kW de services critiques est maintenu. Le contrôle et le modem disposent d’un UPS auxiliaire distinct, à dimensionner.'],
 charger:['Borne avec conversion bidirectionnelle','Borne DC représentative pour un couple compatible. Le convertisseur relie le bus AC et le véhicule. ISO 15118-20 est une cible de communication véhicule–borne selon support réel ; OCPP 2.1 vise la relation borne–supervision. Les capacités exactes doivent être essayées.'],
 ev:['Véhicule — disponibilité conditionnelle','Le propriétaire doit consentir et le constructeur permettre la décharge. Le SoC, l’énergie requise, l’heure de départ et la garantie limitent la flexibilité. Une prise compatible ou V2L ne démontre pas le V2G. Un véhicule absent ne contribue plus au service ni au secours.'],
 ems:['Contrôleur local / EMS + UPS auxiliaire','Il arbitre les consignes d’après le compteur, les plafonds locaux et les sessions. Il privilégie la recharge pilotée avant la décharge. En perte WAN, il garde une stratégie locale sûre et cesse d’accepter de nouvelles consignes distantes. L’UPS du contrôle ne maintient pas la recharge des voitures.'],
 cloud:['Supervision multisite / agrégateur','Elle reçoit des enveloppes de flexibilité datées, répartit les demandes et suit le résultat. Elle retire les télémesures périmées ; elle ne doit ni ignorer un plafond local, ni dépendre d’une communication directe entre toutes les bornes. Identité de session pseudonymisée, pas d’historique de déplacement nécessaire.'],
 firewall:['Passerelle télécom et frontière OT / IT','Accès IP fixe ou mobile, filtrage sortant contrôlé, aucun port public direct sur une borne. Deux opérateurs sont utiles seulement si le service et les causes de panne le justifient. En perte réseau, limites et protections locales restent actives.'],
 guards:['Identité, validité et limites locales','mTLS dans le système cible, permissions par rôle, commande identifiée et expirante, anti-rejeu, contrôle des limites électriques, audit et révocation. Le démonstrateur teste une fonction de décision ; il ne réalise pas le chiffrement ni une authentification industrielle.']
};
function showTab(id,focus=false){
 $$('[role=tab]').forEach(b=>{const on=b.getAttribute('aria-controls')===id;b.setAttribute('aria-selected',on);b.tabIndex=on?0:-1;if(on&&focus)b.focus();});
 $$('[role=tabpanel]').forEach(p=>p.hidden=p.id!==id);
 if(id==='map')drawMap();
}
$$('[role=tab]').forEach((b,i,all)=>{
 b.addEventListener('click',()=>showTab(b.getAttribute('aria-controls')));
 b.addEventListener('keydown',e=>{let next;if(e.key==='ArrowRight')next=(i+1)%all.length;if(e.key==='ArrowLeft')next=(i-1+all.length)%all.length;if(e.key==='Home')next=0;if(e.key==='End')next=all.length-1;if(next!==undefined){e.preventDefault();showTab(all[next].getAttribute('aria-controls'),true);}});
});
$('#reviewRows').innerHTML=ReviewData.review.map((r,i)=>`<article class="reviewitem"><div><span class="num">${String(i+1).padStart(2,'0')} / REVUE</span><h3>${esc(r[0])}</h3></div><div><div class="compare"><div><div class="tag">Hypothèse fragile</div><p>${esc(r[1])}</p><p class="muted">${esc(r[2])}</p></div><div><div class="tag after">Correction retenue</div><p>${esc(r[3])}</p></div></div><div class="proof"><strong>Preuve restant à obtenir :</strong> ${esc(r[4])}</div></div></article>`).join('');
$('#datasets').innerHTML=ReviewData.datasets.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('');
$('#sources').innerHTML=ReviewData.sources.map(r=>`<article class="source" id="${r[0]}"><span class="id">${r[0]} · ${esc(r[3])}</span><h3><a href="${esc(r[2])}" target="_blank" rel="noopener noreferrer">${esc(r[1])} ↗</a></h3><p>${esc(r[4])}</p></article>`).join('');
$$('[data-source]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();showTab('proof');document.getElementById(a.dataset.source).scrollIntoView({block:'center',behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'});}));
$('#gates').innerHTML=ReviewData.gates.map(g=>`<div class="gate"><label class="check"><input type="checkbox" data-gate="${g[0]}"><span>${esc(g[1])}<small>${esc(g[2])}</small></span></label></div>`).join('');
$$('[data-gate]').forEach(c=>c.addEventListener('change',()=>{const n=$$('[data-gate]:checked').length;$('#gateResult').textContent=n===6?'6/6 déclarées — faire examiner les preuves avant tout essai V2G.':`${n}/6 preuves documentées — étude requise.`;}));
$('#scenario').innerHTML=Object.entries(EnergyModel.scenarios).map(([v,t])=>`<option value="${v}">${esc(t)}</option>`).join('');
function options(){return {scenario:$('#scenario').value,reserve:Number($('#reserve').value),target:Number($('#target').value),pv:$('#pv').checked,v2g:$('#v2g').checked,exportAllowed:$('#exportAllowed').checked,backup:$('#backup').checked};}
function inspect(key){selected=key;const r=info[key]||info.ems;$('#inspectTitle').textContent=r[0];$('#inspectText').textContent=r[1];$('#equipment').value=key;$$('.topology .node').forEach(n=>n.classList.toggle('selected',n.dataset.key===key));}
function node(x,y,w,h,key,title,sub='',classes=''){
 return `<g class="node ${classes} ${selected===key?'selected':''}" data-key="${key}" role="button" tabindex="0" aria-label="${esc(title+'. '+sub)}" transform="translate(${x},${y})"><rect width="${w}" height="${h}"/><text x="${w/2}" y="${h/2-5}" text-anchor="middle" font-size="17" font-weight="650">${esc(title)}</text><text x="${w/2}" y="${h/2+17}" text-anchor="middle" font-size="13">${esc(sub)}</text></g>`;
}
function wire(path,power,kind='wire',disabled=false){const active=!disabled&&Math.abs(power)>.001;return `<path d="${path}" class="${kind}${disabled?' disabled':''}" ${active?(power>0?'marker-end="url(#arrow)"':'marker-start="url(#arrow)"'):''}/>`;}
function renderTopology(state=result,mode=layer,targetId="topology",titleId="layerTitle",onInspect=inspect){
 const result=state,layer=mode;
 const mobile=matchMedia('(max-width:600px)').matches;
 const svg=document.getElementById(targetId);const width=mobile?440:880,height=mobile?1040:560;
 svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
 const defs=`<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10Z" fill="${layer==='energy'?'#995500':'#006d68'}"/></marker></defs>`;
 let body='';
 if(layer==='energy'){
  body+=node(width/2-125,6,250,68,'grid','Réseau principal',result.island?'Indisponible':`${fmt(result.total)} kW · bilan des PCC`,'primary');
  if(mobile)body+=wire('M220 74V110',result.sites[0].grid,'wire',result.island)+wire('M345 40H436V575H220V600',result.sites[1].grid,'wire',result.island)+`<text x="14" y="100" font-size="12" fill="#50646a">Raccordements distincts · A et B</text>`;
  else body+=wire('M440 74V91H220V110',result.sites[0].grid,'wire',result.island)+wire('M440 91H660V110',result.sites[1].grid,'wire',result.island);
  result.sites.forEach((s,i)=>{
   const x=mobile?0:i*440,y=mobile?(i===0?110:600):110;
   let t=`<rect class="boundary" x="8" y="0" width="424" height="438" rx="3"/><text x="22" y="26" font-size="15" font-weight="650">SITE ${s.id} · ${i===0?'pilote':'extension'}</text>`;
   const yp=38;
   t+=wire(`M220 0V${yp}`,s.grid,'wire',result.island)+node(145,yp,150,68,'pcc','PCC / mesure',`${fmt(s.grid)} kW`);
   t+=wire(`M220 ${yp+68}V152`,s.grid,'wire',result.island);
   t+=`<path d="M170 152H270" class="wire"/><text x="230" y="181" font-size="13">Bus AC</text>`;
   t+=wire('M135 127H170V152',s.usedPv,'wire',!result.options.pv||result.island);
   t+=node(20,92,115,70,'pv','PV',result.options.pv?`${fmt(s.usedPv)} kW`:'Non retenu','optional');
   t+=wire('M305 127H270V152',s.bess,'wire',!result.options.backup);
   t+=node(305,92,115,70,'bess','Batterie',result.options.backup?`${fmt(s.bess)} kW`:'Option','optional');
   t+=wire('M220 152H80V220',s.servedLoad);
   t+=node(20,220,120,70,'load','Bâtiment',`${fmt(s.servedLoad)} kW`);
   t+=wire('M220 152V220',s.ev);
   t+=node(155,220,130,70,'charger','Borne DC',`${s.mode} ${fmt(Math.abs(s.ev))} kW`,'primary');
   t+=wire('M220 290V330',s.ev);
   t+=node(155,330,130,70,'ev','Véhicule',s.available?`SoC ${fmt(s.socAfter)} %`:'Absent');
   t+=`<path d="M305 360H292V255H285" class="signal"/>`+node(305,330,115,70,'ems','EMS local','+ UPS contrôle');
   t+=`<text x="22" y="423" font-size="12">${result.island?'PCC isolé · aucun échange réseau':`Import ≤ ${s.importLimit} kW · export ${result.options.exportAllowed?'≤ 15 kW':'interdit'}`}</text>`;
   body+=`<g transform="translate(${x},${y})">${t}</g>`;
  });
 }else{
  const mid=width/2;
  body+=node(mid-140,6,280,70,'grid','Interface Senelec','À convenir · aucune API connectée','optional');
  body+=wire(`M${mid} 76V104`,1,'signal');
  body+=node(mid-140,104,280,75,'cloud','Supervision multisite','Enveloppes, dispatch, audit','primary');
  result.sites.forEach((s,i)=>{
   const x=mobile?0:i*440, y=mobile?(i===0?220:620):230;
   const lost=s.wan===false||(s.wan===undefined&&result.options.scenario==='offline'&&s.id==='B');
   const path=mobile?(i===0?`M220 179V${y+15}`:`M360 179H432V${y-15}H220V${y+15}`):`M440 179V201H${x+220}V${y+15}`;
   body+=wire(path,1,'signal',lost);
   let t=`<rect class="boundary" x="8" y="0" width="424" height="350"/><text x="22" y="335" font-size="15" font-weight="650">SITE ${s.id} · ${lost?'WAN perdu / repli local':'contrôle autonome'}</text>`;
   t+=wire('M220 0V15',1,'signal',lost)+node(85,15,270,68,layer==='cyber'?'guards':'firewall',layer==='cyber'?'Identité / validité / rôles':'Passerelle IP / pare-feu',lost?'Pas de nouvelle consigne':'WAN fixe ou mobile · mTLS');
   t+=wire('M220 83V117',1,'signal');
   t+=node(85,117,270,68,'ems','EMS / arbitre local',layer==='cyber'?'Limites · réserve · audit':'Compteur · limites · plan de charge','primary');
   t+=wire('M220 185V208H95V232',1,'signal');t+=wire('M220 208H305V232',1,'signal');
   t+=node(25,232,140,68,'pcc','Compteur PCC','Mesures locales');t+=node(225,232,170,68,'charger','Borne ↔ véhicule','OCPP / ISO 15118');
   body+=`<g transform="translate(${x},${y})">${t}</g>`;
  });
  svg.setAttribute('viewBox',`0 0 ${width} ${mobile?990:600}`);
 }
 svg.innerHTML=defs+body;
 [...svg.querySelectorAll('.node')].forEach(n=>{n.addEventListener('click',()=>onInspect(n.dataset.key));n.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onInspect(n.dataset.key);}});});
 document.getElementById(titleId).textContent=layer==='energy'?'Couche énergie · bilans AC':layer==='data'?'Couche données · IP et contrôle local':'Couche cyber · barrières et arbitre local';
}
function render(){
 result=EnergyModel.run(options());window.lastResult=result;
 $('#reserveValue').textContent=fmt(result.options.reserve)+' %';$('#targetValue').textContent=fmt(result.options.target)+' kW';
 $('#total').textContent=fmt(result.total)+' kW';$('#direction').textContent=result.island?'PCC isolés':result.total<-.001?'Injection nette':result.total>.001?'Import net':'Bilan réseau nul';
 $('#reduction').textContent=result.island?'—':fmt(result.reduction)+' kW';$('#reductionLabel').textContent=result.island?'Coupure ≠ service de flexibilité':`Référence : ${fmt(result.baseline)} kW`;
 $('#unmet').textContent=result.target===null?'—':fmt(result.unmet)+' kW';$('#targetLabel').textContent=result.target===null?'Pas de service demandé':`Objectif : ${fmt(result.target)} kW`;
 $('#systemState').textContent=result.island?'Isolé':result.blocked?'Refus':result.options.scenario==='offline'?'Repli local':'Connecté';$('#stateNote').textContent=result.island?'Recharge suspendue':result.blocked?'Commande distante rejetée':result.options.scenario==='offline'?'Site B non engagé':'Limites du site actives';
 $('#eventTitle').textContent=EnergyModel.scenarios[result.options.scenario];
 let message=result.events.length?result.events.join(' '):'Le réseau alimente les charges et les véhicules. Le solaire réduit l’achat ; la batterie fixe est au repos. La coordination centrale n’annule jamais les limites locales.';
 if(result.target!==null&&result.unmet>.001)message+=` Objectif non atteint : ${fmt(result.unmet)} kW manquants. Le système déclare l’insuffisance au lieu de dépasser une limite.`;
 if(result.target!==null&&!result.options.exportAllowed)message+=' Export interdit : la décharge peut seulement alimenter le site derrière son compteur (V2B), sans injection publique.';
 if(result.autonomy)message+=` Autonomie critique théorique : ${fmt(result.autonomy)} h. Pertes auxiliaires, âge et température non modélisés.`;
 $('#eventText').textContent=message;$('#status').textContent=result.blocked?'REFUS SIMULÉ':result.island?'ISOLEMENT REQUIS':result.unmet>.001?'CAPACITÉ INSUFFISANTE':'EXÉCUTION LOCALE';$('#status').className='status'+(result.blocked?' reject':result.island||result.unmet>.001?' warn':'');
 $('#sitecards').innerHTML=result.sites.map(s=>`<article class="sitecard"><h3>Site ${s.id}<span class="small muted">${s.mode}</span></h3><dl><dt>Raccordement</dt><dd>${fmt(s.grid)} kW</dd><dt>Borne · côté AC</dt><dd>${fmt(s.ev)} kW</dd><dt>Bâtiment servi / solaire utilisé</dt><dd>${fmt(s.servedLoad)} / ${fmt(s.usedPv)} kW</dd><dt>SoC après 15 min</dt><dd>${fmt(s.socAfter)} %</dd><dt>Réserve de départ</dt><dd>${fmt(s.reserve)} %</dd></dl><div class="bar" aria-hidden="true"><div class="level" style="width:${s.socAfter}%"></div><div class="floor" style="left:${s.reserve}%"></div></div><p class="small muted" style="margin-bottom:0">Barre : SoC · trait orange : réserve. ${!s.available?'Véhicule absent.':s.soc<s.reserve?'Réserve supérieure au SoC initial : priorité à recharger, aucune décharge.':'Réserve préservée en décharge.'}</p></article>`).join('');
 renderTopology();inspect(selected);
}
$$('.controls input,.controls select').forEach(e=>e.addEventListener(e.type==='range'?'input':'change',render));
$$('[data-layer]').forEach(b=>b.addEventListener('click',()=>{layer=b.dataset.layer;$$('[data-layer]').forEach(x=>x.setAttribute('aria-pressed',x===b));renderTopology();inspect(layer==='cyber'?'guards':layer==='data'?'cloud':'ems');}));
matchMedia('(max-width:600px)').addEventListener('change',()=>renderTopology());
$('#animate').addEventListener('click',()=>{const s=$('#topology');s.classList.remove('pulse');void s.getBoundingClientRect();s.classList.add('pulse');setTimeout(()=>s.classList.remove('pulse'),3100);});
$('#print').addEventListener('click',()=>window.print());
$('#exportCase').addEventListener('click',()=>{const blob=new Blob([JSON.stringify({type:'simulation-pedagogique',revision:'R1',date:new Date().toISOString(),...result},null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='Dakar_V2G_Cas_Simule.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);});
const bbox=[-17.55,14.60,-17.10,14.87];
const merc=lat=>Math.log(Math.tan(Math.PI/4+lat*Math.PI/360));
function project(c){return [(c[0]-bbox[0])/(bbox[2]-bbox[0])*700,(merc(bbox[3])-merc(c[1]))/(merc(bbox[3])-merc(bbox[1]))*360];}
function parseGeoJSON(data){
 if(!data||data.type!=='FeatureCollection'||!Array.isArray(data.features)||!data.features.length||data.features.length>1000)throw Error('FeatureCollection attendue, contenant 1 à 1 000 objets.');
 let count=0;const check=c=>{if(!Array.isArray(c)||c.length<2||!Number.isFinite(c[0])||!Number.isFinite(c[1])||Math.abs(c[0])>180||Math.abs(c[1])>=85)throw Error('Coordonnées WGS84 invalides ou hors limites de projection.');if(++count>50000)throw Error('Plus de 50 000 coordonnées. Réduisez la couche dans QGIS.');return [c[0],c[1]];};
 const line=x=>{if(!Array.isArray(x)||x.length<2)throw Error('Ligne invalide.');return x.map(check);};
 const polygon=x=>{if(!Array.isArray(x)||!x.length)throw Error('Polygone invalide.');return x.map(r=>{const a=line(r);if(a.length<4||a[0][0]!==a.at(-1)[0]||a[0][1]!==a.at(-1)[1])throw Error('Anneau de polygone non fermé.');return a;});};
 const features=data.features.map(f=>{if(f?.type!=='Feature'||!f.geometry)throw Error('Objet Feature sans géométrie.');const g=f.geometry;let c;if(g.type==='Point')c=check(g.coordinates);else if(g.type==='MultiPoint')c=g.coordinates.map(check);else if(g.type==='LineString')c=line(g.coordinates);else if(g.type==='MultiLineString')c=g.coordinates.map(line);else if(g.type==='Polygon')c=polygon(g.coordinates);else if(g.type==='MultiPolygon')c=g.coordinates.map(polygon);else throw Error('Type de géométrie non pris en charge.');return {type:g.type,coordinates:c};});
 return {features,count};
}
function drawMap(){
 let html='<defs><clipPath id="mapclip"><rect width="700" height="360"/></clipPath></defs><rect width="700" height="360" fill="#edf4f2"/>';
 for(let i=1;i<5;i++){html+=`<path d="M${i*140} 0V360M0 ${i*72}H700" stroke="#c6d8d2" stroke-width="1"/>`;}
 html+='<text x="15" y="24" font-size="13" fill="#50646a">Cadre Dakar · projection Mercator · sans fond chargé</text>';
 const cities=[['Dakar',[-17.434,14.677]],['Pikine',[-17.392,14.755]],['Keur Massar',[-17.31,14.785]]];
 for(const [name,c] of cities){let [x,y]=project(c);html+=`<circle cx="${x}" cy="${y}" r="5" fill="#50646a"/><text x="${x+10}" y="${y+5}" font-size="16">${name}</text>`;}
 const path=line=>line.map((c,i)=>{const p=project(c);return (i?'L':'M')+p.map(n=>n.toFixed(2)).join(' ');}).join(' ');
 let objects='';
 if(imported)for(const g of imported.features){const pts=c=>{const p=project(c);return `<circle class="geopoint" cx="${p[0]}" cy="${p[1]}" r="6"/>`;};
  if(g.type==='Point')objects+=pts(g.coordinates);if(g.type==='MultiPoint')objects+=g.coordinates.map(pts).join('');
  if(g.type==='LineString')objects+=`<path class="geoline" style="fill:none" d="${path(g.coordinates)}"/>`;
  if(g.type==='MultiLineString')objects+=g.coordinates.map(c=>`<path class="geoline" style="fill:none" d="${path(c)}"/>`).join('');
  if(g.type==='Polygon')objects+=`<path class="geoline" fill-rule="evenodd" d="${g.coordinates.map(c=>path(c)+'Z').join(' ')}"/>`;
  if(g.type==='MultiPolygon')objects+=g.coordinates.map(p=>`<path class="geoline" fill-rule="evenodd" d="${p.map(c=>path(c)+'Z').join(' ')}"/>`).join('');
 }
 html+=`<g clip-path="url(#mapclip)">${objects}</g><text x="15" y="346" font-size="12">Ouest ${bbox[0]}° / Est ${bbox[2]}° · repères approximatifs, pas de bornes</text>`;
 $('#geomap').innerHTML=html;
}
function localMap(){ $('#onlineMap').hidden=true;$('#geomap').hidden=false; }
$('#loadMap').addEventListener('click',()=>{let f=$('#onlineMap');f.src='https://www.openstreetmap.org/export/embed.html?bbox=-17.55%2C14.60%2C-17.10%2C14.87&layer=mapnik';f.hidden=false;$('#geomap').hidden=true;$('#mapStatus').textContent='Fond OpenStreetMap en ligne · © contributeurs OpenStreetMap, ODbL. Chargement externe soumis à la connexion. La couche importée reste visible dans la vue locale.';});
$('#offlineMap').addEventListener('click',()=>{localMap();$('#mapStatus').textContent=imported?`Couche locale : ${imported.features.length} objets, ${imported.count} coordonnées. Aucun réseau électrique validé.`:'Vue locale sans routes ni réseau électrique. Repères approximatifs ; aucune borne existante affichée.';});
$('#geoFile').addEventListener('change',async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>2*1024*1024)throw Error('Fichier supérieur à 2 Mo.');const parsed=parseGeoJSON(JSON.parse(await f.text()));imported=parsed;localMap();drawMap();$('#mapStatus').textContent=`Import local : ${parsed.features.length} objets, ${parsed.count} coordonnées. Couche déclarée par l’utilisateur ; provenance et aptitude électrique non validées.`;}catch(err){$('#mapStatus').textContent='Import refusé : '+err.message;}finally{e.target.value='';}});
$('#clearGeo').addEventListener('click',()=>{imported=null;localMap();drawMap();$('#mapStatus').textContent='Couche effacée. Vue locale sans données de raccordement.';});
window.DakarDemo={model:EnergyModel,parseGeoJSON,project,showTab};
$('#equipment').innerHTML=Object.entries(info).map(([key,v])=>`<option value="${key}">${esc(v[0])}</option>`).join('');
$('#equipment').addEventListener('change',e=>inspect(e.target.value));
render();drawMap();
