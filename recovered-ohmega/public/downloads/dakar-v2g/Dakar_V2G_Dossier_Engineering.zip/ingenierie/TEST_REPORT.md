# Rapport de vérification R1 — 9 octobre 2026

## TST-001 — modèle énergétique et limites

Commande : `node tests/model.cjs`. PASS. 4 000 combinaisons : 10 scénarios × PV actif/inactif × bidirectionnalité active/inactive × export autorisé/interdit × secours actif/inactif × 5 réserves × 5 objectifs.

Vérifications : somme des PCC ; conservation AC (réseau + solaire + BESS = charges + borne) ; limites d’import/export ; charge ≤ 22 kW et décharge ≤ 6 kW ; réserve lors d’une décharge ; véhicule absent ; isolement ; calcul kWh avec rendement ; mesures B retirées des engagements après perte WAN. Cinq références chiffrées et dix cas de refus, plus rejeu après une acceptation.

EV-003 : evidence/model-results.json. Paramètres : capacité 60 kWh, pas 0,25 h, rendement de chaque sens 0,94 ; limites et bases documentées dans model.js. Tolérance 1e-8. Modèle quasi-statique, aucune tension, fréquence, température ou vieillissement.

## TST-002 — navigateur réel

PASS sous Chromium 153.0.8010.0, Playwright. Neuf tailles : 1440×900, 1280×800, 1024×768, 820×1180, 768×1024, 430×932, 390×844, 360×800, 320×700. 90 couples scénario/vue et 36 couples onglet/vue.

Contrôles supplémentaires : export JSON, reserve, V1G/V2G, interfaces de couche, inspection, navigation clavier, préférence de mouvement réduit, coupure, refus de commandes, checklist, source interne, import GeoJSON valide/invalide avec propriété hostile et CSS d’impression. Aucune erreur de page et aucune requête externe dans le parcours hors ligne.

EV-004 : evidence/browser-results.json. Captures desktop.png et mobile.png examinées. Les tables larges disposent d’un défilement interne. Aucun audit exhaustif WCAG ni test physique sur téléphone n’est revendiqué. Le fond OSM externe a été volontairement exclu du test réseau ; sa disponibilité en ligne est NON TESTÉE.

## Historique des corrections

- Première exécution navigateur : FAIL d’assertion, le test attendait un signe moins typographique alors que Intl produit `-2`. Correction de l’attente du test ; aucun défaut de puissance associé.
- Revue du test avant reprise : mise à jour des curseurs range par leur événement input, plutôt que fill non pris en charge.
- Reprise : PASS.
- Inspection visuelle : étiquette batterie trop longue, liaison PCC et bus incomplète graphiquement, lien d’évitement capturé hors écran et pointillés de l’animation en mouvement réduit. Corrections SVG/CSS/capture.
- Renforcement de politique : horloge locale de contexte, durée maximale 15 s, inscription de l’identifiant accepté et rejet des consignes non nulles en coupure ; TST-001 relancé, PASS.
- Contre-vérification finale après corrections graphiques : TST-002 relancé, PASS.

Ces résultats n’attestent ni l’interopérabilité OCPP/ISO, ni un certificat TLS, ni un raccordement, ni un dispositif d’îlotage réel.


## Extension R2 — 10 octobre 2026

TST-S01 / EV-S01 — PASS : `node tests/temporal.cjs`, 96 séquences (V2G, export, secours et trois réserves × quatre programmes), 311 042 contrôles de pas et 11 essais supplémentaires. Pas de 5 s. Bilans AC et DC vérifiés par équations distinctes du solveur, tolérance 1e-7 ; SoC, réserve, absence, limites, isolement, énergie non servie et pertes. Référence charge DC = 22 × 10/60 × 0,94 kWh. Référence secours total = 2 × 12 × (0,70 − 0,40) × 0,90 = 6,48 kWh AC. Déterminisme, cyber sans effet énergétique, départ anticipé, retour sans énergie inventée, surplus PV, défaut WAN et événement final vérifiés.

TST-S02 / EV-S02 — PASS : `node tests/simulation-browser.mjs`, Chromium 153.0.8010.0 et Playwright 1.62.1. Lecture/pause, pas 60 s, reset, configuration verrouillée, historique sans rembobinage physique ; panne/WAN/attaque, événements programmés/suppression/passé refusé ; V1G/V2G et comparaison ; exports JSON/CSV analysés ; vitesse 120 min/s donnant exactement le même rapport que finish ; épuisement du secours. Vue 3D : rotation boutons/clavier/glisser, zoom, sélection clavier, sites A/B et placement sans effet électrique. 40 couples couche/vue sur dix tailles, dont paysage 844×390. Zéro erreur de page et zéro requête externe dans le parcours testé. OSM non chargé, disponibilité en ligne NON TESTÉE.

TST-001 et TST-002 relancés sur R2 : PASS, 4 000 cas historiques et 90 couples scénario/vue, 36 couples onglet/vue. Captures R2 desktop/outage/mobile examinées (EV-S03). Aucune revendication d'audit WCAG complet, de test sur téléphone physique, ou de qualification réseau.

Historique R2 : revue avant essais corrige l'événement exactement en fin d'horizon et le traitement de départ. Premier lancement navigateur BLOQUÉ par extraction du binaire (chown EINVAL) ; extraction locale sans propriétaire système résout le problème, aucun changement de critères. Premier parcours UI FAIL : isDisabled sur le fieldset n'est pas la bonne assertion Playwright ; test vérifie désormais le champ enfant réellement désactivé. Deuxième parcours FAIL utile : V2G ne décharge jamais car une borne inférieure de recharge forcée à zéro annule la décharge autorisée. Correction de la contrainte, ajout d'un essai fonctionnel V1G/V2G dans le modèle, puis TST-S01 et TST-S02 PASS. Revue UI : batterie fixe absente désormais nommée non installée et retirée des séries SoC. Vitesse quantifiée avec reste de secondes, sans arrondir chaque tick vers le haut.

Résultats pour données fictives du programme support, export supposé autorisé : V1G recharge 28,7 kWh AC, décharge 0, import 48,7, export 0, écart cumulé 9,7 kWh ; V2G recharge 39,7, décharge 9,7, import 55,8, export 5,9, écart 0. Le V2G suit mieux la consigne dans ce cas, mais ne prouve aucune économie d'énergie ou rentabilité.

Évaluation séquentielle avec tests séparés du calcul ; aucune certification indépendante professionnelle. Le PASS concerne le logiciel pédagogique, pas l'installation.


TST-S03 — PASS : archive ZIP intégralement lisible, 55 entrées, empreintes SHA-256 de toutes les entrées contrôlées ; HTML reconstruit depuis les seules sources distribuées identique octet pour octet au livrable.
